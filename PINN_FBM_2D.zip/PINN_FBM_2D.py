"""PINN_FBM_2D.py -- physics-informed (H, D, sigma_loc) estimator for 2D FBM windows.

2D counterpart of PINN_FBM_3D.py.  Identical physics, losses, exposure model
and log10 convention; the only structural change is C = 2 axes (x, y)
sharing one increment covariance instead of C = 3.

Convention (fixed, do not change):
    C(s,t)            = D (s^2H + t^2H - |t-s|^2H)     per axis
    MSD(t)            = 2 D t^2H                       per axis
                      = 4 D t^2H                       summed over x, y
    Var[dx over dt]   = 2 D dt^2H                      per axis

D is therefore the SAME quantity as in the 3D model: an isotropic 3D fBm
projected onto the xy plane is exactly a 2D fBm with the same (H, D), so a
2D estimate on xy-projected 3D data is directly comparable with the 3D
estimate on the full track -- only with 2/3 of the information.

Checkpoints carry config["ndim"] = 2; the 2D inference scripts refuse a 3D
checkpoint (and vice versa via the input-layer width), because the two are
not interchangeable: in_dim = 2(N-1)+2 here, 3(N-1)+2 in 3D.

Every tunable lives in the Config dataclass below.  Edit it there, or
override any field from the command line (--num-points, --h-range LO HI, ...).
"""

from __future__ import annotations

import argparse
import math
import os
from contextlib import contextmanager
from dataclasses import asdict, dataclass, fields

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

torch.set_default_dtype(torch.float32)

LOG2PI = math.log(2.0 * math.pi)   # natural: part of the Gaussian density
LN10 = math.log(10.0)              # 2.302585...
LOG10E = 1.0 / LN10                # nats -> dex
MODEL_VERSION = 4                  # 4: known constant exposure blur, log10 D
NDIM = 2                           # spatial axes sharing one covariance
AXES = ("x", "y")
R_MIN = 1e-3                       # smallest resolvable nonzero duty cycle


# ==========================================================================
# CONFIGURATION -- the single place to change anything
# ==========================================================================

@dataclass
class Config:
    # ---- window and acquisition ------------------------------------------
    num_points: int = 20          # points per window (>= 3)
    exposure_R: float = 0.05      # T_E/dt duty cycle; 0 = instantaneous
    r_jitter: float = 0.10        # +/- relative uncertainty on R in training

    # ---- simulator priors ------------------------------------------------
    h_range: tuple = (0.04, 0.96)        # uniform
    log10D_range: tuple = (-5.0, 1.0)    # uniform in dex
    dt_range: tuple = (0.01, 0.03)       # log-uniform
    snr_range: tuple = (19, 21)          # log-uniform

    # ---- network ---------------------------------------------------------
    hidden: int = 256
    h_margin: float = 0.02               # net H range = h_range +/- margin
    d_offset_dex: float = 2.0 * LOG10E   # bound on the learned log10 D offset
    sigma_ratio_range: tuple = (1e-2, 1.0)   # sigma_loc / increment RMS
    sigma_feature_floor: float = 1e-3        # clamp on the input ratio feature

    # ---- losses ----------------------------------------------------------
    physics_weight: float = 1.0
    sigma_weight: float = LN10 ** 2

    # ---- training --------------------------------------------------------
    epochs: int = 15000
    batch_size: int = 512
    lr: float = 3e-4
    weight_decay: float = 1e-4
    grad_clip: float = 1.0
    physics_warmup: int = 500
    p_known: float = 0.5          # fraction of the batch given sigma_loc
    seed: int = 0

    # ---- evaluation ------------------------------------------------------
    eval_every: int = 100
    val_batches: int = 8
    val_seed: int = 12345
    test_cases: int = 40
    test_batch_size: int = 256
    extreme_log10D_range: tuple = (0.0, 2.0)
    extreme_dt: float = 0.02
    extreme_snr: float = 20.0
    mismatch_rel_errors: tuple = (-0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3)

    # ---- output ----------------------------------------------------------
    ckpt_fmt: str = "fbm_pinn_2D_N{n}_R{r}.pt"

    def __post_init__(self):
        for f in fields(self):
            if isinstance(getattr(self, f.name), list):
                setattr(self, f.name, tuple(getattr(self, f.name)))
        self.validate()

    # -- derived -----------------------------------------------------------
    @property
    def num_inc(self) -> int:
        return self.num_points - 1

    @property
    def h_net_range(self) -> tuple:
        """Sigmoid output range for H: the prior, padded, kept inside (0, 1)."""
        lo = max(1e-3, self.h_range[0] - self.h_margin)
        hi = min(1.0 - 1e-3, self.h_range[1] + self.h_margin)
        return (lo, hi)

    @property
    def log_sigma_ratio_range(self) -> tuple:
        lo, hi = self.sigma_ratio_range
        return (math.log10(lo), math.log10(hi))

    @property
    def ckpt(self) -> str:
        return self.ckpt_fmt.format(n=self.num_points, r=f"{self.exposure_R:g}")

    # -- checks ------------------------------------------------------------
    def validate(self) -> "Config":
        if self.num_points < 3:
            raise ValueError(f"num_points must be >= 3, got {self.num_points}")
        if self.exposure_R != 0.0 and not (R_MIN <= self.exposure_R <= 1.0):
            raise ValueError(
                f"exposure_R must be 0 or in [{R_MIN}, 1], got {self.exposure_R}")
        if not (0.0 <= self.r_jitter < 1.0):
            raise ValueError(f"r_jitter must be in [0, 1), got {self.r_jitter}")
        for name in ("h_range", "log10D_range", "dt_range", "snr_range",
                     "sigma_ratio_range", "extreme_log10D_range"):
            lo, hi = getattr(self, name)
            if not lo < hi:
                raise ValueError(f"{name} must satisfy lo < hi, got {(lo, hi)}")
        # parenthesised: `not a and b` binds as `(not a) and b`
        if not (0.0 < self.h_range[0] and self.h_range[1] < 1.0):
            raise ValueError(f"h_range must lie inside (0, 1), got {self.h_range}")
        for name in ("dt_range", "snr_range", "sigma_ratio_range"):
            if getattr(self, name)[0] <= 0.0:
                raise ValueError(f"{name} must be positive (it is log-uniform)")
        if not 0.0 <= self.p_known <= 1.0:
            raise ValueError(f"p_known must be in [0, 1], got {self.p_known}")
        return self


CFG = Config()


def _cfg(cfg: Config | None = None) -> Config:
    """Resolve a config at CALL time, so reassigning CFG reaches every default."""
    return CFG if cfg is None else cfg


# ==========================================================================
# Utilities
# ==========================================================================

def xavier_init(module):
    if isinstance(module, nn.Linear):
        nn.init.xavier_uniform_(module.weight)
        nn.init.zeros_(module.bias)


@contextmanager
def fixed_rng(seed, device=None):
    """Run a block under a fixed seed, then restore the global RNG state."""
    cpu_state = torch.get_rng_state()
    cuda_state = (torch.cuda.get_rng_state_all()
                  if torch.cuda.is_available() else None)
    torch.manual_seed(seed)
    try:
        yield
    finally:
        torch.set_rng_state(cpu_state)
        if cuda_state is not None:
            torch.cuda.set_rng_state_all(cuda_state)


def _pow_2H(u, p):
    """|u|^p with an exact zero at u == 0 and a finite gradient."""
    mask = u > 0
    safe = torch.where(mask, u, torch.ones_like(u))
    return torch.where(mask, safe.pow(p), torch.zeros_like(u))


def stable_cholesky(Sigma, jitter=1e-8, max_tries=7):
    """Cholesky with jitter RELATIVE to the matrix scale."""
    n = Sigma.shape[-1]
    eye = torch.eye(n, device=Sigma.device, dtype=Sigma.dtype)
    scale = torch.diagonal(Sigma, dim1=-2, dim2=-1).mean(-1).clamp(min=1e-30)
    scale = scale[:, None, None]
    for _ in range(max_tries):
        L, info = torch.linalg.cholesky_ex(Sigma + jitter * scale * eye)
        if not bool(info.any()):
            return L
        jitter *= 10.0
    raise RuntimeError("Cholesky failed after jitter escalation")


def increments(x, y):
    """(B, N) x2 -> (B, N-1, 2) increments, axis last."""
    return torch.stack([x[:, 1:] - x[:, :-1], y[:, 1:] - y[:, :-1]], dim=-1)


# ==========================================================================
# Exposure blur (dynamic localisation error) -- dimension independent
# ==========================================================================

def _blur_phi(u, H2, T):
    """Exposure-averaged fGN kernel  Phi(u) = E_s |u + s|^2H."""
    p = H2 + 2.0
    num = (_pow_2H(u + T, p) + _pow_2H((u - T).abs(), p) - 2.0 * _pow_2H(u, p))
    return num / (T * T * (p - 1.0) * p)


def _kernel(u, H2, T):
    """|u|^2H if T is None (instantaneous sampling), else the blurred Phi."""
    return _pow_2H(u, H2) if T is None else _blur_phi(u, H2, T)


def blur_variance_factor(H, R):
    """kappa(H, R) = Var[blurred lag-1 increment] / (2 D dt^2H)."""
    Hd = H.double()
    R = torch.as_tensor(R, dtype=torch.float64, device=H.device)
    Rs = R.clamp(min=R_MIN)
    p = 2.0 * Hd + 2.0
    one = torch.ones_like(Hd)
    k = (_pow_2H((1.0 + Rs) * one, p) + _pow_2H((1.0 - Rs).abs() * one, p)
         - 2.0 - 2.0 * _pow_2H(Rs * one, p)) / (Rs * Rs * (p - 1.0) * p)
    return torch.where(R > 0, k, one).to(H.dtype)


# ==========================================================================
# fGN covariance (with exposure blur and localisation noise)
# ==========================================================================

def increment_covariance(t, H, D, sigma_loc=None, R=None):
    """Per-axis covariance of observed increments.  t:(B,N), H,D,sigma_loc,R:(B,).

    Dimension independent: every axis shares this matrix.  D is LINEAR.
    Returns (B, N-1, N-1) in FLOAT64.
    """
    t = t.double()
    left, right = t[:, :-1], t[:, 1:]

    li, ri = left[:, :, None], right[:, :, None]
    lj, rj = left[:, None, :], right[:, None, :]

    H2 = (2.0 * H.double())[:, None, None]
    Dm = D.double()[:, None, None]

    T = None
    if R is not None:
        R = torch.as_tensor(R, dtype=torch.float64, device=t.device)
        R = R.expand(t.shape[0]) if R.dim() == 0 else R
        if bool((R > 0).any()):
            if not bool((R > 0).all()):
                raise ValueError("mixed zero / nonzero R within one batch")
            dt = (t[:, 1:] - t[:, :-1]).mean(dim=1)
            T = (R.clamp(R_MIN, 1.0) * dt)[:, None, None]

    Sigma = Dm * (
        _kernel((ri - lj).abs(), H2, T)
        + _kernel((li - rj).abs(), H2, T)
        - _kernel((ri - rj).abs(), H2, T)
        - _kernel((li - lj).abs(), H2, T)
    )

    if sigma_loc is not None:
        n = Sigma.shape[-1]
        idx = torch.arange(n, device=t.device)
        band = (idx[:, None] - idx[None, :]).abs()
        noise = torch.where(band == 0, 2.0, torch.where(band == 1, -1.0, 0.0))
        Sigma = Sigma + (sigma_loc.double() ** 2)[:, None, None] * noise.double()

    return Sigma


def gaussian_nll(X, Sigma):
    """Exact multivariate Gaussian NLL, averaged per element.

    X : (B, n, C) -- C independent axes sharing Sigma (C = 2 here).
    """
    _, n, C = X.shape
    out_dtype = X.dtype
    X, Sigma = X.double(), Sigma.double()
    L = stable_cholesky(Sigma)
    alpha = torch.cholesky_solve(X, L)
    mahal = (X * alpha).sum(dim=(1, 2))
    logdet = 2.0 * torch.log(torch.diagonal(L, dim1=-2, dim2=-1)).sum(dim=1)
    nll = 0.5 * (mahal + C * logdet + C * n * LOG2PI)
    return (nll.mean() / (n * C)).to(out_dtype)


def fbm_physics_loss(x, y, t, H, log10D, sigma_loc, R=None):
    """R: per-trajectory TRUE duty cycle of the simulated data (B,)."""
    dX = increments(x, y)
    Sigma = increment_covariance(t, H, torch.pow(10.0, log10D.double()),
                                 sigma_loc, R)
    return gaussian_nll(dX, Sigma)


# ==========================================================================
# Network
# ==========================================================================

class FBMPINN(nn.Module):
    """Inputs 2x(N-1) RMS-normalised increments.  No dt, no absolute scale.

    Outputs: H, sigma_H, log10D, sigma_log10D, sigma_loc.
    """

    ndim = NDIM

    def __init__(self, cfg: Config | None = None):
        super().__init__()
        cfg = _cfg(cfg).validate()
        self.cfg = cfg
        self.num_points = cfg.num_points
        self.num_inc = cfg.num_inc
        self.version = MODEL_VERSION
        self.register_buffer("exposure_R",
                             torch.tensor(cfg.exposure_R, dtype=torch.float64))

        self.h_lo, self.h_hi = cfg.h_net_range
        self.d_offset_dex = cfg.d_offset_dex
        self.log_sig_lo, self.log_sig_hi = cfg.log_sigma_ratio_range
        self.log_sig_mid = 0.5 * (self.log_sig_lo + self.log_sig_hi)
        self.log_sig_half = 0.5 * (self.log_sig_hi - self.log_sig_lo)

        hidden = cfg.hidden
        in_dim = self.num_inc * NDIM + 2   # + log10(sigma_loc/s), known flag
        self.shared = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, 128), nn.SiLU(),
            nn.Linear(128, 64), nn.SiLU(),
        )
        self.h_head = nn.Sequential(nn.Linear(64, 32), nn.SiLU(), nn.Linear(32, 2))
        self.d_head = nn.Sequential(nn.Linear(64, 32), nn.SiLU(), nn.Linear(32, 2))
        self.s_head = nn.Sequential(nn.Linear(64, 32), nn.SiLU(), nn.Linear(32, 1))
        self.apply(xavier_init)

    # -- checkpoint round trip --------------------------------------------
    @classmethod
    def from_checkpoint(cls, path, device=None, cfg=None):
        """Rebuild a model exactly as it was trained."""
        ck = torch.load(path, map_location=device or "cpu", weights_only=False)
        stored = dict(ck.get("config", {}))
        nd = stored.get("ndim", 3)
        if nd != NDIM:
            raise ValueError(f"{path}: checkpoint is {nd}D, this module is "
                             f"{NDIM}D")
        base = asdict(_cfg(cfg))
        known = {f.name for f in fields(Config)}
        base.update({k: v for k, v in stored.items() if k in known})
        model = cls(Config(**base))
        model.load_state_dict(ck["model_state"])
        return model.to(device) if device else model, ck

    @staticmethod
    def _dt(t):
        d = t[:, 1:] - t[:, :-1]
        return d.mean(dim=1).clamp(min=1e-12)

    def forward(self, x, y, t, sigma_loc=None, sigma_known=None):
        if x.shape[1] != self.num_points:
            raise ValueError(
                f"model was built for {self.num_points}-point windows, "
                f"got {x.shape[1]}")

        inc = increments(x, y)                                  # (B,n,2)
        s2 = inc.pow(2).mean(dim=(1, 2)).clamp(min=1e-30)       # (B,)
        s = torch.sqrt(s2)
        f = (inc / s[:, None, None]).flatten(1)                 # scale free

        floor = self.cfg.sigma_feature_floor
        if sigma_loc is None:
            known = torch.zeros_like(s)
            ratio = torch.full_like(s, self.log_sig_mid)
        else:
            known = (torch.ones_like(s) if sigma_known is None
                     else sigma_known.to(s.dtype))
            ratio = torch.log10((sigma_loc / s).clamp(floor, 1.0))
            ratio = torch.where(known > 0, ratio,
                                torch.full_like(s, self.log_sig_mid))

        h = self.shared(torch.cat([f, ratio[:, None], known[:, None]], dim=1))

        raw_h, raw_hs = self.h_head(h).unbind(-1)
        H = self.h_lo + (self.h_hi - self.h_lo) * torch.sigmoid(raw_h)
        sigma_H = F.softplus(raw_hs - 2.0) + 1e-3

        raw_r, raw_rs = self.d_head(h).unbind(-1)
        r = self.d_offset_dex * torch.tanh(raw_r / 2.0)
        dt = self._dt(t)
        # s2 is a PER-AXIS mean square increment (mean over axes as well as
        # lags), so the reconstruction is identical to 3D: s2 ~ 2 D dt^2H kappa
        kappa = blur_variance_factor(H, self.exposure_R)
        log10D = (r + torch.log10(s2)
                  - 2.0 * H * torch.log10(dt) - math.log10(2.0)
                  - torch.log10(kappa))
        sigma_log10D = LOG10E * (F.softplus(raw_rs - 1.0) + 1e-3)

        log10_ratio = (self.log_sig_mid
                       + self.log_sig_half * torch.tanh(self.s_head(h).squeeze(-1)))
        sigma_out = s * torch.pow(10.0, log10_ratio)
        if sigma_loc is not None:
            sigma_out = torch.where(known > 0, sigma_loc, sigma_out)

        return H, sigma_H, log10D, sigma_log10D, sigma_out


# ==========================================================================
# Losses
# ==========================================================================

def het_nll(pred, target, sigma):
    """Heteroscedastic Gaussian NLL."""
    return (0.5 * ((pred - target) / sigma) ** 2 + torch.log(sigma)).mean()


def total_loss(x, y, t, out, H_true, log10D_true, sigma_true,
               cfg=None, physics_weight=None, sigma_weight=None,
               sigma_known=None, R=None):
    cfg = _cfg(cfg)
    physics_weight = cfg.physics_weight if physics_weight is None else physics_weight
    sigma_weight = cfg.sigma_weight if sigma_weight is None else sigma_weight
    H, sH, log10D, sD, sig = out

    physics = fbm_physics_loss(x, y, t, H, log10D, sig, R)
    nll_H = het_nll(H, H_true, sH)
    nll_D = het_nll(log10D, log10D_true, sD)

    # per-axis increment RMS (mean over lags and the NDIM axes)
    s_rms = torch.sqrt(increments(x, y).pow(2).mean(dim=(1, 2)))
    lo, hi = cfg.sigma_ratio_range
    tgt = torch.log10((sigma_true / s_rms).clamp(min=lo, max=hi))
    m = (torch.ones_like(s_rms) if sigma_known is None
         else 1.0 - sigma_known.to(s_rms.dtype))
    mse_sig = (((torch.log10(sig / s_rms) - tgt) ** 2) * m).sum() / m.sum().clamp(min=1.0)

    loss = physics_weight * physics + nll_H + nll_D + sigma_weight * mse_sig
    return loss, physics, nll_H, nll_D


# ==========================================================================
# Simulator
# ==========================================================================

def generate_fbm_dataset(batch_size=1024, cfg=None, device="cpu", *,
                         num_points=None, exposure_R=None, r_jitter=None,
                         h_range=None, log10D_range=None, dt_range=None,
                         snr_range=None,
                         H_fixed=None, log10D_fixed=None, dt_fixed=None,
                         snr_fixed=None, R_fixed=None):
    """2D FBM with exposure blur and localisation noise.

    Returns x, y, t, H, log10D, sigma_loc, R_true.
    """
    cfg = _cfg(cfg)
    num_points = cfg.num_points if num_points is None else int(num_points)
    exposure_R = cfg.exposure_R if exposure_R is None else float(exposure_R)
    r_jitter = cfg.r_jitter if r_jitter is None else float(r_jitter)
    h_range = h_range or cfg.h_range
    log10D_range = log10D_range or cfg.log10D_range
    dt_range = dt_range or cfg.dt_range
    snr_range = snr_range or cfg.snr_range

    def _u(lo, hi, fixed):
        if fixed is not None:
            return torch.full((batch_size,), float(fixed), device=device)
        return lo + torch.rand(batch_size, device=device) * (hi - lo)

    def _logu10(rng, fixed):
        lo, hi = math.log10(rng[0]), math.log10(rng[1])
        f = None if fixed is None else math.log10(fixed)
        return torch.pow(10.0, _u(lo, hi, f))

    H = _u(*h_range, H_fixed)
    log10D = _u(*log10D_range, log10D_fixed)
    D = torch.pow(10.0, log10D)
    dt = _logu10(dt_range, dt_fixed)
    snr = _logu10(snr_range, snr_fixed)

    t = torch.arange(num_points, device=device, dtype=dt.dtype)[None, :] * dt[:, None]

    if R_fixed is not None:
        R_true = torch.full((batch_size,), float(R_fixed), device=device)
        R_true = R_true.clamp(R_MIN, 1.0) if float(R_fixed) > 0 else R_true
    elif exposure_R > 0:
        R_true = (exposure_R * (1.0 + r_jitter * (2.0 * torch.rand(
            batch_size, device=device) - 1.0))).clamp(R_MIN, 1.0)
    else:
        R_true = torch.zeros(batch_size, device=device)

    Sigma = increment_covariance(t, H, D, R=R_true)
    L = stable_cholesky(Sigma)
    noise = torch.randn(batch_size, num_points - 1, NDIM, device=device,
                        dtype=torch.float64)
    inc = torch.bmm(L, noise)                                   # (B,n,2)

    pos = torch.zeros(batch_size, num_points, NDIM, device=device,
                      dtype=torch.float64)
    pos[:, 1:] = torch.cumsum(inc, dim=1)

    # SNR := (per-axis UNBLURRED fGN increment std) / sigma_loc
    sigma_loc = torch.sqrt(2.0 * D * dt.pow(2.0 * H)) / snr
    pos = pos + sigma_loc.double()[:, None, None] * torch.randn_like(pos)
    pos = (pos - pos[:, 0:1, :]).to(torch.get_default_dtype())

    x, y = pos[..., 0], pos[..., 1]
    return x, y, t, H, log10D, sigma_loc, R_true


# ==========================================================================
# Evaluation
# ==========================================================================

@torch.no_grad()
def evaluate_model(model, cfg=None, device=None, batch_size=None,
                   batches=None, p_known=None, seed=None, **kw):
    """Validation on a FIXED set of windows."""
    cfg = _cfg(cfg)
    batch_size = cfg.batch_size if batch_size is None else batch_size
    batches = cfg.val_batches if batches is None else batches
    p_known = cfg.p_known if p_known is None else p_known
    seed = cfg.val_seed if seed is None else seed
    kw.setdefault("exposure_R", float(model.exposure_R))

    was_training = model.training
    model.eval()
    tot = H_e = D_e = cov_H = cov_D = 0.0
    with fixed_rng(seed, device):
        for _ in range(batches):
            x, y, t, H_true, log10D_true, sig_true, R_true = generate_fbm_dataset(
                batch_size=batch_size, cfg=cfg, device=device, **kw)
            known = (torch.rand(batch_size, device=device) < p_known).float()
            out = model(x, y, t, sig_true, known)
            loss, *_ = total_loss(x, y, t, out, H_true, log10D_true,
                                  sig_true, cfg=cfg, sigma_known=known, R=R_true)
            H, sH, log10D, sD, _ = out
            tot += loss.item()
            H_e += (H - H_true).abs().mean().item()
            D_e += (log10D - log10D_true).abs().mean().item()
            cov_H += ((H - H_true).abs() <= 1.96 * sH).float().mean().item()
            cov_D += ((log10D - log10D_true).abs() <= 1.96 * sD).float().mean().item()
    model.train(was_training)
    n = float(batches)
    return tot / n, H_e / n, D_e / n, cov_H / n, cov_D / n


# ==========================================================================
# Training
# ==========================================================================

def train_fbm_pinn(cfg=None, ckpt=None, device=None):
    cfg = _cfg(cfg).validate()
    ckpt = ckpt or cfg.ckpt

    torch.manual_seed(cfg.seed)
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Running on: {device}")
    print(f"2D window: {cfg.num_points} points ({cfg.num_inc} increments "
          f"x {NDIM} axes) -> {ckpt}")
    if cfg.exposure_R > 0:
        print(f"Exposure: R = T_E/dt = {cfg.exposure_R:g} "
              f"(training R_true within +/-{100 * cfg.r_jitter:g}%)")
    else:
        print("Exposure: instantaneous sampling (R = 0)")
    print(f"Priors: H {cfg.h_range}, log10D {cfg.log10D_range} dex, "
          f"dt {cfg.dt_range} (log-uniform), SNR {cfg.snr_range} (log-uniform)")
    print("D is reported as log10(D) [dex]")
    check_blur_kernel()

    model = FBMPINN(cfg).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=cfg.lr,
                            weight_decay=cfg.weight_decay)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=8, min_lr=1e-6)

    best = float("inf")
    print("\nStarting training\n")

    for epoch in range(cfg.epochs):
        model.train()
        x, y, t, H_true, log10D_true, sig_true, R_true = generate_fbm_dataset(
            batch_size=cfg.batch_size, cfg=cfg, device=device)

        known = (torch.rand(cfg.batch_size, device=device) < cfg.p_known).float()

        w = cfg.physics_weight * min(1.0, epoch / max(1, cfg.physics_warmup))
        out = model(x, y, t, sig_true, known)
        loss, phys, nll_H, nll_D = total_loss(
            x, y, t, out, H_true, log10D_true, sig_true, cfg=cfg,
            physics_weight=w, sigma_known=known, R=R_true)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        optimizer.step()

        if epoch % cfg.eval_every == 0 or epoch == cfg.epochs - 1:
            v_loss, H_mae, D_mae, cH, cD = evaluate_model(model, cfg, device)
            scheduler.step(v_loss)
            lr = optimizer.param_groups[0]["lr"]
            print(f"Epoch {epoch:5d} | val {v_loss:8.4f} | phys {phys.item():8.4f} "
                  f"| H MAE {H_mae:6.4f} | log10D MAE {D_mae:6.4f} dex "
                  f"| cov {cH:4.2f}/{cD:4.2f} | LR {lr:.1e}")

            if v_loss < best:
                best = v_loss
                config = asdict(cfg)
                config.update({
                    "version": MODEL_VERSION,
                    "ndim": NDIM,
                    "convention": "MSD = 2 D t^(2H) per axis",
                    "log": "log10",
                    "exposure_model": "box, T_E = R dt at frame start",
                    "snr_definition": "unblurred increment std / sigma_loc",
                })
                torch.save({"epoch": epoch,
                            "model_state": model.state_dict(),
                            "optimizer_state": optimizer.state_dict(),
                            "loss": best,
                            "config": config}, ckpt)
                print("  -> saved best model")

    print("\nTraining completed.")
    return model


# ==========================================================================
# Tests
# ==========================================================================

@torch.no_grad()
def check_blur_kernel(num_points=5, K=400, tol=5e-3, dt=17.0, D=0.3,
                      R_values=(0.05, 0.3, 1.0), H_values=(0.1, 0.5, 0.9),
                      verbose=True):
    """Verify the closed-form blurred covariance against brute force."""
    worst_bf, worst_k = 0.0, 0.0
    for R in R_values:
        for Hv in H_values:
            t = (torch.arange(num_points, dtype=torch.float64) * dt)[None]
            H = torch.tensor([Hv], dtype=torch.float64)
            Dt = torch.tensor([D], dtype=torch.float64)
            S = increment_covariance(
                t, H, Dt, R=torch.tensor([R], dtype=torch.float64))[0]

            T = R * dt
            u = (torch.arange(K, dtype=torch.float64) + 0.5) * T / K
            du = (u[:, None] - u[None, :])[None, None]
            l, r = t[0, :-1], t[0, 1:]
            li, ri = l[:, None, None, None], r[:, None, None, None]
            lj, rj = l[None, :, None, None], r[None, :, None, None]
            pw = lambda a: a.abs().pow(2.0 * Hv)
            bf = D * (pw(ri - lj + du) + pw(li - rj + du)
                      - pw(ri - rj + du) - pw(li - lj + du)).mean(dim=(-2, -1))

            scale = 2.0 * D * dt ** (2.0 * Hv)
            worst_bf = max(worst_bf, float(((S - bf).abs() / scale).max()))
            kap = float(blur_variance_factor(H, R))
            worst_k = max(worst_k, abs(float(S[0, 0]) / scale - kap))
    ok = worst_bf < tol and worst_k < 1e-9
    if verbose:
        print(f"Blur kernel check: max |closed form - brute force| = "
              f"{worst_bf:.1e}, max |Sigma_11 - kappa| = {worst_k:.1e} "
              f"(units of 2 D dt^2H) -> {'OK' if ok else 'FAILED'}")
    if not ok:
        raise RuntimeError("blurred covariance failed its self-check")
    return worst_bf, worst_k


@torch.no_grad()
def test_model(model, device, cfg=None, cases=None, batch_size=None,
               known_sigma=False, seed=None, **kw):
    cfg = _cfg(cfg)
    cases = cfg.test_cases if cases is None else cases
    batch_size = cfg.test_batch_size if batch_size is None else batch_size
    kw.setdefault("exposure_R", float(model.exposure_R))
    was_training = model.training
    model.eval()
    H_t, H_p, D_t, D_p = [], [], [], []
    with fixed_rng(cfg.val_seed if seed is None else seed, device):
        for _ in range(cases):
            x, y, t, H_true, log10D_true, sig, _ = generate_fbm_dataset(
                batch_size=batch_size, cfg=cfg, device=device, **kw)
            H, _, log10D, _, _ = (model(x, y, t, sig) if known_sigma
                                  else model(x, y, t))
            H_t.append(H_true.cpu()); H_p.append(H.cpu())
            D_t.append(log10D_true.cpu()); D_p.append(log10D.cpu())
    model.train(was_training)
    H_t, H_p = torch.cat(H_t), torch.cat(H_p)
    D_t, D_p = torch.cat(D_t), torch.cat(D_p)
    print(f"\n========== TEST RESULTS (2D, N={cfg.num_points}, "
          f"R={kw['exposure_R']:g}, "
          f"{'known' if known_sigma else 'unknown'} sigma_loc) ==========")
    print(f"Hurst exponent MAE : {(H_p - H_t).abs().mean():.6f}")
    print(f"log10(D) MAE       : {(D_p - D_t).abs().mean():.6f} dex")
    print("==================================\n")
    return H_t, H_p, D_t, D_p


@torch.no_grad()
def extreme_H_test(model, device, cfg=None, dt=None, snr=None,
                   H_values=(0.05, 0.25, 0.5, 0.75, 0.95), batch_size=512):
    cfg = _cfg(cfg)
    dt = cfg.extreme_dt if dt is None else dt
    snr = cfg.extreme_snr if snr is None else snr
    R0 = float(model.exposure_R)
    was_training = model.training
    model.eval()
    print(f"\nExtreme Hurst test (2D, N={cfg.num_points}, dt={dt}, SNR={snr}, "
          f"R={R0:g} exact, log10D in {cfg.extreme_log10D_range} dex)")
    for Hv in H_values:
        x, y, t, H_true, log10D_true, _, _ = generate_fbm_dataset(
            batch_size=batch_size, cfg=cfg, device=device,
            H_fixed=Hv, dt_fixed=dt, snr_fixed=snr,
            log10D_range=cfg.extreme_log10D_range, R_fixed=R0)
        H, _, log10D, _, _ = model(x, y, t)
        print(f"True H={Hv:.2f} | Pred H={H.mean().item():.4f} "
              f"+/- {H.std().item():.4f} | log10D bias "
              f"{(log10D - log10D_true).mean().item():+.4f} dex")
    model.train(was_training)


@torch.no_grad()
def exposure_mismatch_test(model, device, cfg=None, rel_errors=None,
                           batch_size=2048, cases=4):
    """Bias when the effective exposure differs from the nominal R."""
    cfg = _cfg(cfg)
    rel_errors = cfg.mismatch_rel_errors if rel_errors is None else rel_errors
    R0 = float(model.exposure_R)
    if R0 <= 0:
        print("\nExposure mismatch test skipped (model trained at R = 0)")
        return
    was_training = model.training
    model.eval()
    print(f"\nExposure mismatch test (2D, N={cfg.num_points}, nominal R={R0:g})")
    print("  delta R |  R_true | H bias  | H MAE  | log10D bias | log10D MAE")
    for d in rel_errors:
        Rt = min(max(R0 * (1.0 + d), R_MIN), 1.0)
        hb = hm = db = dm = 0.0
        for _ in range(cases):
            x, y, t, H_true, log10D_true, _, _ = generate_fbm_dataset(
                batch_size=batch_size, cfg=cfg, device=device, R_fixed=Rt)
            H, _, log10D, _, _ = model(x, y, t)
            hb += (H - H_true).mean().item() / cases
            hm += (H - H_true).abs().mean().item() / cases
            db += (log10D - log10D_true).mean().item() / cases
            dm += (log10D - log10D_true).abs().mean().item() / cases
        print(f"  {d:+6.0%}  | {Rt:7.4f} | {hb:+.4f} | {hm:.4f} | "
              f"{db:+.4f} dex | {dm:.4f} dex")
    model.train(was_training)


# ==========================================================================
# Command line -- one flag per Config field, generated automatically
# ==========================================================================

def build_parser(cfg: Config) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Train / test the 2D (H, D, sigma_loc) FBM PINN.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    for f in fields(cfg):
        v = getattr(cfg, f.name)
        flag = "--" + f.name.replace("_", "-")
        if isinstance(v, tuple):
            p.add_argument(flag, type=float, nargs=len(v), default=None,
                           help=f"(default {v})")
        else:
            p.add_argument(flag, type=type(v), default=None,
                           help=f"(default {v!r})")
    p.add_argument("--ckpt", type=str, default=None,
                   help="explicit checkpoint path (overrides --ckpt-fmt)")
    p.add_argument("--no-train", action="store_true",
                   help="load --ckpt and run the tests only")
    return p


def config_from_args(args, cfg: Config) -> Config:
    base = asdict(cfg)
    for f in fields(cfg):
        v = getattr(args, f.name, None)
        if v is not None:
            base[f.name] = tuple(v) if isinstance(v, list) else v
    return Config(**base)


if __name__ == "__main__":
    args = build_parser(CFG).parse_args()
    CFG = config_from_args(args, CFG)
    ckpt_path = args.ckpt or CFG.ckpt

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if args.no_train:
        model, ck = FBMPINN.from_checkpoint(ckpt_path, device, CFG)
        CFG = model.cfg
    else:
        train_fbm_pinn(cfg=CFG, ckpt=ckpt_path, device=device)
        model, ck = FBMPINN.from_checkpoint(ckpt_path, device, CFG)
    print("Loaded best checkpoint from epoch", ck["epoch"])

    test_model(model, device, CFG, known_sigma=False)
    test_model(model, device, CFG, known_sigma=True)
    extreme_H_test(model, device, CFG)
    exposure_mismatch_test(model, device, CFG)

    print(f"Best checkpoint: {os.path.abspath(ckpt_path)}")
