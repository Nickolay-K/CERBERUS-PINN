"""
INFER_PINN_FBM_3D_EXPERIMENTAL.py
=================================

Sliding-window inference for the joint (H, D, sigma_loc) PINN estimator on
REAL experimental trajectories.

This is the simulated-data sliding script plus everything an experimental
file needs and a simulation has already guaranteed:

    ingest      column auto-detection (TrackMate / trackpy / Imaris / generic)
    convert     pixels -> length, frames -> time, anisotropic z step
    clean       NaNs, duplicate timepoints, gap-filled linker runs, stuck
                particles
    drift       ensemble-median stage drift removal
    check       isotropy of motion and of localisation precision; 2D refusal
    score       the same windowing, the same network, the same combination
    validate    simulation-calibrated goodness of fit per window

The scoring core is IMPORTED from the sliding script, not copied, so the
window extraction, the common-mode combination and the delta method cannot
drift out of sync between the two.  Keep the three files under their stable
names in one directory:

    PINN_FBM_3D.py                     network and training
    INFER_PINN_FBM_3D_SLIDING.py       scoring core
    INFER_PINN_FBM_3D_EXPERIMENTAL.py  this file

Version the checkpoints, not the source files -- a date-stamped .py is
invisible to `import`.

Logarithm convention
--------------------
D is log10 throughout.  The network returns log10 D and its sd in dex; the
core refuses a natural-log (version-2) checkpoint at load time, because such
a file runs without error and returns D^(1/ln10).  The only place ln(10)
appears here is the delta method,

    D_error = D_predicted * ln(10) * sigma_log10D

which is a SYMMETRIC 1-sd bar on a lognormal posterior.  D_low and D_high
(= 10^(log10D -/+ sigma)) are the honest interval; prefer them for plots.

Units
-----
Positions are multiplied by --pixel-size (and z by --z-step if it differs);
frame indices are multiplied by --frame-interval.  Set --pixel-size 1 if the
file is already calibrated.  D is then reported in

    [length]^2 / [time]^(2H)      under   MSD(t) = 2 D t^(2H)

Note the exponent: D is NOT in length^2/time unless H = 0.5, so comparing D
across tracks with different H compares quantities of different dimension.
Use --msd-lag for that; it emits the MSD at a fixed lag, in length^2.

The training dt_range does not have to contain the experimental dt: the D
reconstruction subtracts 2H*log10(dt) analytically and the network's residual
head never sees dt.  What a very different dt does change is where the data
land relative to the training log10D prior, which is what the rail warning
reports.

Exposure
--------
For simulated data the duty cycle R = T_E/dt is known exactly.  For a real
acquisition it comes from the camera settings and MUST be supplied
(--exposure-time in the same units as the converted time, or --exposure-r).
Guessing is not safe: exposure blur and low H produce the same signature in
the increment correlation, so an unknown R trades directly against H.

What is NOT handled
-------------------
* 2D data.  The network shares one covariance across three axes; supplying
  z = 0 deflates s^2 by exactly 1/3, a -0.477 dex bias in D.  Refused.
* Anisotropic D or anisotropic sigma_loc.  Measured and reported, not
  corrected -- a fix needs a per-axis model, not a preprocessing step.
* Confinement, drift within a track, or any non-fBm mechanism.  The
  goodness-of-fit columns are what surface these; they do not correct them.
"""

from __future__ import annotations

import argparse
import hashlib
import math
import os
import sys
from dataclasses import dataclass, field, fields

import numpy as np
import pandas as pd
import torch

LN10 = math.log(10.0)
TAPERS = ("none", "parabolic")

_DESCRIPTION = ("PINN sliding-window inference on experimental SPT tracks: "
                "per-timepoint H(t), D(t), sigma_loc and goodness of fit.")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ==========================================================================
# Scoring core and network
# ==========================================================================

import INFER_PINN_FBM_3D_SLIDING as _core          # noqa: E402

assert getattr(_core, "MIN_MODEL_VERSION", 0) >= 3, (
    f"{_core.__file__} is the pre-log10 sliding script (it would return "
    f"D^(1/ln10)); update it to the revision that defines InferConfig.")

_net = _core._net
load_model = _core.load_model
split_segments = _core.split_segments
scatter_combine = _core.scatter_combine
scatter_geomean = _core.scatter_geomean
track_exposure = _core.track_exposure
check_exposure = _core.check_exposure
_block = _core._block

for _fn in ("increment_covariance", "stable_cholesky", "blur_variance_factor",
            "generate_fbm_dataset", "Config"):
    if not hasattr(_net, _fn):
        raise ImportError(
            f"The network module {_net.__name__} has no {_fn}; the "
            f"goodness-of-fit calibration needs the current training script.")


# ==========================================================================
# Column schemas
# ==========================================================================

# keys are lowercase, stripped of spaces, underscores and dots; the order
# within each tuple is the match priority (TRACK_ID beats ID)
COLUMN_ALIASES = {
    "pid":  ("pid", "trackid", "track", "trackno", "particle", "trajectory",
             "cellid", "spotid", "id"),
    "x":    ("x", "positionx", "xum", "xpx", "xpos", "xcoord"),
    "y":    ("y", "positiony", "yum", "ypx", "ypos", "ycoord"),
    "z":    ("z", "positionz", "zum", "zpx", "zpos", "zcoord"),
    "t":    ("t", "time", "positiont", "tsec", "timesec"),
    "frame": ("frame", "framenumber", "framei", "slice", "timepoint",
              "framenum"),
    "sigma_loc": ("sigmaloc", "locerror", "localizationerror",
                  "localisationerror", "localizationprecision", "uncertainty",
                  "ep"),
}


def _key(c):
    return (str(c).strip().lower()
            .replace(" ", "").replace("_", "").replace(".", ""))


def detect_columns(df, overrides):
    """Map the file's columns onto the canonical names."""
    have = {}
    for c in df.columns:                     # first occurrence wins
        have.setdefault(_key(c), c)
    out, how = {}, {}
    for canon, aliases in COLUMN_ALIASES.items():
        if overrides.get(canon):
            name = overrides[canon]
            if name not in df.columns:
                raise ValueError(f"--col-{canon} names a column that is not "
                                 f"in the file: {name!r}")
            out[canon], how[canon] = name, "explicit"
            continue
        for a in aliases:
            if a in have:
                out[canon], how[canon] = have[a], "detected"
                break
    return out, how


# ==========================================================================
# CONFIGURATION
# ==========================================================================

def _opt(default, typ, help="", **meta):
    return field(default=default, metadata={"type": typ, "help": help, **meta})


@dataclass
class ExpConfig:
    # ---- input / output --------------------------------------------------
    input: str = "Control_frame1000-1200_tracks.csv"
    output: str = "predictions_Control_frame1000-1200_tracks.csv"
    track_summary: str = _opt(None, str, "per-track summary CSV")
    window_output: str = _opt(None, str, "raw per-window estimates")
    weights: str = "fbm_pinn_N20_SNR20_R0.05_dt17.pt"
    log10_output: bool = _opt(None, bool, "also emit log10D columns [dex]")

    # ---- column overrides ------------------------------------------------
    col_pid: str = _opt(None, str, "track id column")
    col_x: str = _opt(None, str, "")
    col_y: str = _opt(None, str, "")
    col_z: str = _opt(None, str, "")
    col_t: str = _opt(None, str, "time column (physical units)")
    col_frame: str = _opt(None, str, "frame index column; t = frame * dt")
    col_sigma_loc: str = _opt(None, str, "per-point localisation precision")

    # ---- units -----------------------------------------------------------
    pixel_size: float = 1.0        # length per xy unit in the file
    z_step: float = _opt(None, float, "length per z unit; defaults to pixel_size")
    frame_interval: float = 1.0    # time per frame, if t comes from frames
    length_unit: str = "um"
    time_unit: str = "s"

    # ---- exposure --------------------------------------------------------
    exposure_time: float = _opt(None, float, "T_E in converted time units")
    exposure_r: float = _opt(None, float, "duty cycle T_E/dt, if known directly")
    r_tol: float = _opt(None, float, "accepted relative R mismatch")
    allow_r_mismatch: bool = _opt(None, bool, "warn instead of refusing")

    # ---- windowing -------------------------------------------------------
    num_points: int = _opt(None, int, "override the checkpoint window length")
    stride: int = 1
    taper: str = _opt("none", str, "", choices=TAPERS)
    min_windows: int = 1
    dt: float = _opt(None, float, "nominal sampling interval, converted units")
    dt_tol: float = 1e-3

    # ---- localisation ----------------------------------------------------
    sigma_loc: float = _opt(None, float,
                            "one localisation precision for the whole file")

    # ---- hygiene ---------------------------------------------------------
    drop_duplicate_t: bool = True
    max_zero_frac: float = 0.10    # per track, fraction of exactly-zero steps
    # an immobile particle has per-axis increment RMS sqrt(2)*sigma_loc, so
    # the threshold is stuck_factor times THAT, not times sigma_loc
    stuck_factor: float = 1.5
    min_increment_rms: float = _opt(None, float,
                                    "absolute stuck threshold if sigma unknown")
    drift_correct: bool = _opt(None, bool,
                               "subtract the ensemble median displacement")
    drift_min_particles: int = 10
    aniso_warn: float = 2.0        # warn above this per-axis variance ratio

    # ---- goodness of fit -------------------------------------------------
    gof: bool = True
    gof_sims: int = 512            # simulated windows per calibration cell
    gof_h_grid: int = 7
    gof_snr_grid: int = 5
    gof_snr_range: tuple = (2.0, 100.0)
    gof_min_count: int = 64        # below this a bin falls back to the pool
    gof_alpha: float = 0.05        # p below this counts as a misfit
    gof_cache: str = _opt(None, str, "npz file to cache the null calibration")

    # ---- reporting -------------------------------------------------------
    msd_lag: float = _opt(None, float,
                          "also report MSD at this lag (converted time units)")
    rail_tol: float = 1e-3
    rail_warn_frac: float = 0.02

    # ---- compute ---------------------------------------------------------
    batch_size: int = 1024
    device: str = _opt(None, str, "cuda / cpu")
    seed: int = 0

    def __post_init__(self):
        for n in ("log10_output", "allow_r_mismatch", "drift_correct"):
            if getattr(self, n) is None:
                setattr(self, n, False)
        if isinstance(self.gof_snr_range, list):
            self.gof_snr_range = tuple(self.gof_snr_range)
        if self.z_step is None:
            self.z_step = self.pixel_size
        self.validate()

    def validate(self):
        if self.stride < 1:
            raise ValueError("stride must be >= 1")
        if self.min_windows < 1:
            raise ValueError("min_windows must be >= 1")
        if self.batch_size < 1:
            raise ValueError("batch_size must be >= 1")
        if self.num_points is not None and self.num_points < 3:
            raise ValueError("num_points must be >= 3")
        if self.taper not in TAPERS:
            raise ValueError(f"taper must be one of {TAPERS}")
        if self.exposure_r is not None and self.exposure_time is not None:
            raise ValueError("give --exposure-r or --exposure-time, not both")
        if self.exposure_r is not None and not 0.0 <= self.exposure_r <= 1.0:
            raise ValueError("exposure_r must lie in [0, 1]")
        for n in ("pixel_size", "z_step", "frame_interval", "dt_tol"):
            if getattr(self, n) <= 0:
                raise ValueError(f"{n} must be positive")
        if self.dt is not None and self.dt <= 0:
            raise ValueError("dt must be positive")
        if not 0.0 <= self.max_zero_frac <= 1.0:
            raise ValueError("max_zero_frac must lie in [0, 1]")
        if self.stuck_factor < 0:
            raise ValueError("stuck_factor must be >= 0")
        if self.drift_min_particles < 2:
            raise ValueError("drift_min_particles must be >= 2")
        if self.aniso_warn <= 1.0:
            raise ValueError("aniso_warn must be > 1")
        if self.gof_sims < 64:
            raise ValueError("gof_sims < 64 gives a useless null distribution")
        if self.gof_h_grid < 2 or self.gof_snr_grid < 2:
            raise ValueError("gof_h_grid and gof_snr_grid must be >= 2")
        lo, hi = self.gof_snr_range
        if not 0 < lo < hi:
            raise ValueError("gof_snr_range must satisfy 0 < lo < hi")
        if not 0.0 < self.gof_alpha < 1.0:
            raise ValueError("gof_alpha must lie in (0, 1)")
        if self.gof_min_count < 8:
            raise ValueError("gof_min_count must be >= 8")
        return self

    @property
    def torch_device(self):
        return torch.device(self.device) if self.device else torch.device(
            "cuda" if torch.cuda.is_available() else "cpu")

    @property
    def d_unit(self):
        return f"{self.length_unit}^2/{self.time_unit}^(2H)"


CFG = ExpConfig()


# ==========================================================================
# Ingest, convert, clean
# ==========================================================================

def ingest(cfg: ExpConfig):
    """Read the file and return a canonical frame in physical units."""
    print(f"Reading {cfg.input}")
    sep = "\t" if cfg.input.lower().endswith((".tsv", ".txt")) else ","
    df = pd.read_csv(cfg.input, sep=sep)
    df.columns = [str(c).strip() for c in df.columns]

    # TrackMate writes three alias rows under the real header
    if len(df) > 3 and not pd.api.types.is_numeric_dtype(df.iloc[:, -1]):
        probe = pd.to_numeric(df.iloc[:, -1], errors="coerce")
        if probe.iloc[:3].isna().all() and probe.iloc[3:].notna().mean() > 0.9:
            print("  dropping 3 TrackMate sub-header rows")
            df = df.iloc[3:].reset_index(drop=True)

    over = {k[4:]: getattr(cfg, k) for k in
            ("col_pid", "col_x", "col_y", "col_z", "col_t", "col_frame",
             "col_sigma_loc")}
    cols, how = detect_columns(df, over)

    for need in ("pid", "x", "y"):
        if need not in cols:
            raise ValueError(
                f"Could not find a '{need}' column. Present: "
                f"{list(df.columns)[:20]}...  Use --col-{need} to name it.")
    if "z" not in cols:
        raise ValueError(
            "No z column found. This network shares one covariance across "
            "three axes; running it on 2D data with z = 0 deflates the mean "
            "square increment by exactly 1/3, i.e. a -0.477 dex bias in D "
            "plus a distorted H. Retrain the network with C = 2 axes for 2D "
            "data, or pass --col-z if the column is named unusually.")
    if "t" not in cols and "frame" not in cols:
        raise ValueError("No time or frame column found; use --col-t or "
                         "--col-frame.")

    print("  columns: " + ", ".join(
        f"{k}={v!r}[{how[k]}]" for k, v in cols.items()))

    out = pd.DataFrame({"pid": df[cols["pid"]].to_numpy()})
    for a, scale in (("x", cfg.pixel_size), ("y", cfg.pixel_size),
                     ("z", cfg.z_step)):
        out[a] = pd.to_numeric(df[cols[a]], errors="coerce").to_numpy() * scale
    if "t" in cols:
        out["t"] = pd.to_numeric(df[cols["t"]], errors="coerce").to_numpy()
        tsrc = f"column {cols['t']!r}"
    else:
        fr = pd.to_numeric(df[cols["frame"]], errors="coerce").to_numpy()
        out["t"] = fr * cfg.frame_interval
        out["frame"] = fr
        tsrc = f"frame {cols['frame']!r} * {cfg.frame_interval}"
    if "sigma_loc" in cols:
        # the localisation precision is an xy quantity, so it scales with
        # pixel_size even when z_step differs
        out["sigma_loc"] = (pd.to_numeric(df[cols["sigma_loc"]],
                                          errors="coerce").to_numpy()
                            * cfg.pixel_size)
    for c in _core.R_COLUMNS:
        if c in df.columns:
            out[c] = pd.to_numeric(df[c], errors="coerce").to_numpy()

    print(f"  units: xy x {cfg.pixel_size} {cfg.length_unit}, "
          f"z x {cfg.z_step} {cfg.length_unit}, t from {tsrc} "
          f"[{cfg.time_unit}]")
    return out


def clean(df, cfg: ExpConfig):
    """Drop unusable rows and tracks; report every removal."""
    n0 = len(df)
    df = df.dropna(subset=["pid", "x", "y", "z", "t"])
    if len(df) < n0:
        print(f"  dropped {n0 - len(df)} rows with non-numeric or missing "
              f"coordinates")

    df = df.sort_values(["pid", "t"], kind="mergesort")
    if cfg.drop_duplicate_t:
        n1 = len(df)
        df = df.drop_duplicates(subset=["pid", "t"], keep="first")
        if len(df) < n1:
            print(f"  dropped {n1 - len(df)} duplicate (pid, t) rows")

    keep, n_tiny, n_zero, n_stuck = [], 0, 0, 0
    for _, tr in df.groupby("pid", sort=False):
        if len(tr) < 3:
            n_tiny += 1
            continue
        d = np.diff(tr[["x", "y", "z"]].to_numpy(np.float64), axis=0)

        # runs of exactly zero displacement = linker gap fill, not motion
        if float((np.linalg.norm(d, axis=1) == 0).mean()) > cfg.max_zero_frac:
            n_zero += 1
            continue

        # per-axis increment RMS; an immobile particle sits at sqrt(2)*sigma
        rms = float(np.sqrt((d ** 2).mean()))
        if cfg.sigma_loc is not None:
            floor = cfg.stuck_factor * math.sqrt(2.0) * cfg.sigma_loc
        elif "sigma_loc" in tr.columns and tr["sigma_loc"].notna().any():
            floor = (cfg.stuck_factor * math.sqrt(2.0)
                     * float(tr["sigma_loc"].median()))
        else:
            floor = cfg.min_increment_rms or 0.0
        if floor > 0 and rms < floor:
            n_stuck += 1
            continue
        keep.append(tr)

    if n_tiny:
        print(f"  dropped {n_tiny} tracks shorter than 3 points")
    if n_zero:
        print(f"  dropped {n_zero} tracks with >{100*cfg.max_zero_frac:g}% "
              f"exactly-zero steps (gap-filled by the linker)")
    if n_stuck:
        print(f"  dropped {n_stuck} immobile tracks (increment RMS below "
              f"{cfg.stuck_factor} x sqrt(2) x the localisation precision)")
    if not keep:
        raise ValueError("no tracks survived cleaning")
    return pd.concat(keep, ignore_index=True)


def correct_drift(df, cfg: ExpConfig):
    """Subtract the ensemble median displacement, frame by frame.

    Stage drift is a coherent motion shared by every particle; left in, it
    adds a ballistic component that the estimator reads as high H.

    The median displacement is labelled at the LATER frame of each step, so
    reindexing onto the full frame list and cumulative-summing gives a drift
    that is exactly zero at the first frame.
    """
    key = "frame" if "frame" in df.columns else "t"
    df = df.sort_values(["pid", key], kind="mergesort").copy()
    g = df.groupby("pid", sort=False)
    step = pd.DataFrame({a: g[a].diff() for a in ("x", "y", "z")})
    step[key] = df[key].to_numpy()
    step = step.dropna()
    if step.empty:
        print("  drift correction skipped: no displacements")
        return df

    med = step.groupby(key)[["x", "y", "z"]].median()
    cnt = step.groupby(key).size()
    ok = (cnt >= cfg.drift_min_particles).reindex(med.index).fillna(False)
    if int(ok.sum()) < 2:
        print(f"  drift correction skipped: fewer than "
              f"{cfg.drift_min_particles} particles on all but "
              f"{int(ok.sum())} frames")
        return df

    # axis=0 aligns the Series on the INDEX; without it pandas aligns on the
    # columns and silently blanks the whole frame
    med = med.where(ok, 0.0, axis=0)

    frames = np.sort(df[key].unique())
    drift = med.reindex(frames).fillna(0.0).cumsum()
    for a in ("x", "y", "z"):
        df[a] = df[a].to_numpy() - df[key].map(drift[a]).to_numpy()

    tot = float(np.linalg.norm(drift.iloc[-1].to_numpy()))
    print(f"  drift corrected over {int(ok.sum())} frames "
          f"(net {tot:.3g} {cfg.length_unit})")
    return df


def isotropy_report(df, cfg: ExpConfig):
    """Per-axis increment variance -- the model shares one Sigma over x,y,z."""
    rows = [[float(np.nanvar(np.diff(tr[a].to_numpy(np.float64))))
             for a in ("x", "y", "z")]
            for _, tr in df.groupby("pid", sort=False) if len(tr) > 1]
    if not rows:
        return None
    v = np.asarray(rows, float)
    v = v[np.isfinite(v).all(1) & (v > 0).all(1)]
    if not len(v):
        return None
    med = np.median(v, axis=0)
    ratio = med[2] / math.sqrt(med[0] * med[1])
    print(f"  per-axis increment variance (median over {len(v)} tracks): "
          f"x {med[0]:.3g}, y {med[1]:.3g}, z {med[2]:.3g}  ->  "
          f"z/xy = {ratio:.2f}, x/y = {med[0] / med[1]:.2f}")
    if ratio > cfg.aniso_warn or ratio < 1.0 / cfg.aniso_warn:
        print(f"  WARNING: z differs from xy by {ratio:.2f}x. The network "
              f"assumes one D and one sigma_loc for all three axes, so both "
              f"anisotropic motion and the usual worse z localisation bias "
              f"the result. Treat D as an xy-weighted average, or fit a "
              f"per-axis model.")
    return dict(var_x=med[0], var_y=med[1], var_z=med[2], z_over_xy=ratio)


# ==========================================================================
# Window evaluation and residual statistics
# ==========================================================================

def _evaluate(model, xb, yb, zb, tb, sl, R_ckpt, want_gof):
    """Run the network on a batch of windows and return the raw outputs.

    Returns H, sigma_H, log10D, sigma_log10D, sigma_loc, s2, T, rho1.

    T and rho1 are whitened-residual statistics under Sigma(theta_hat),
    z = L^-1 dX.  Under the model z is standard normal and independent, so

        T    = mean(z^2)                     -> 1
        rho1 = lag-1 autocorrelation of z    -> 0

    T catches a wrong D or a wrong sigma_loc; rho1 catches a wrong H or a
    wrong exposure, which both leave structure a variance statistic cannot
    see.
    """
    H, sH, l10D, s10D, sg = model(xb, yb, zb, tb, sl)
    dX = torch.stack([xb[:, 1:] - xb[:, :-1],
                      yb[:, 1:] - yb[:, :-1],
                      zb[:, 1:] - zb[:, :-1]], dim=-1)
    s2 = dX.pow(2).mean(dim=(1, 2))
    if not want_gof:
        nan = torch.full_like(H, float("nan"))
        return H, sH, l10D, s10D, sg, s2, nan, nan.clone()

    R = torch.full_like(H, R_ckpt) if R_ckpt > 0 else None
    Sigma = _net.increment_covariance(
        tb, H, torch.pow(10.0, l10D.double()), sg, R)
    L = _net.stable_cholesky(Sigma)
    z = torch.linalg.solve_triangular(L, dX.double(), upper=False)
    T = z.pow(2).mean(dim=(1, 2))
    num = (z[:, :-1, :] * z[:, 1:, :]).sum(dim=(1, 2))
    den = z.pow(2).sum(dim=(1, 2)).clamp(min=1e-30)
    return H, sH, l10D, s10D, sg, s2, T.to(H.dtype), (num / den).to(H.dtype)


def _snr_eff(H, sigma, s2, R_ckpt):
    """Effective SNR of a window from its own estimates (tensors in, np out).

    s^2 = blurred fGn variance + 2 sigma^2, so the unblurred fGn increment
    std is sqrt(max(s^2 - 2 sigma^2, 0) / kappa) and SNR = that / sigma --
    the same definition the simulator uses.
    """
    kap = _net.blur_variance_factor(H, R_ckpt)
    fgn = torch.sqrt(torch.clamp(s2 - 2.0 * sigma ** 2, min=1e-30) / kap)
    return (fgn / sigma.clamp(min=1e-30)).detach().cpu().numpy()


# ==========================================================================
# Goodness-of-fit null
# ==========================================================================

@dataclass
class GofNull:
    h_edges: np.ndarray
    snr_edges: np.ndarray
    T: np.ndarray          # concatenated, sorted within each bin
    Rho: np.ndarray
    offsets: np.ndarray    # len = n_bins + 1
    pooled_T: np.ndarray
    pooled_Rho: np.ndarray
    min_count: int

    @property
    def n_snr(self):
        return len(self.snr_edges) - 1

    def bin_index(self, H, snr):
        i = np.clip(np.digitize(H, self.h_edges) - 1, 0, len(self.h_edges) - 2)
        j = np.clip(np.digitize(snr, self.snr_edges) - 1, 0, self.n_snr - 1)
        return i * self.n_snr + j

    def pvalues(self, H, snr, T_stat, rho_stat):
        """p-values for both statistics, looked up bin by bin."""
        b = self.bin_index(np.asarray(H, float), np.asarray(snr, float))
        pT = np.empty(len(b)); pR = np.empty(len(b))
        for bi in np.unique(b):
            m = b == bi
            lo, hi = self.offsets[bi], self.offsets[bi + 1]
            if hi - lo >= self.min_count:
                nt, nr = self.T[lo:hi], self.Rho[lo:hi]
            else:
                nt, nr = self.pooled_T, self.pooled_Rho
            f = np.searchsorted(nt, T_stat[m]) / len(nt)
            pT[m] = 2.0 * np.minimum(f, 1.0 - f)             # two-sided
            f = np.searchsorted(nr, np.abs(rho_stat[m])) / len(nr)
            pR[m] = 1.0 - f                                  # upper tail
        return np.clip(pT, 0.0, 1.0), np.clip(pR, 0.0, 1.0)


def calibrate_gof(model, n, R_ckpt, cfg: ExpConfig, device, known_sigma):
    """Empirical null for (T, |rho1|), binned by the ESTIMATED (H, SNR).

    Simulation-calibrated, not chi-squared: theta_hat is fitted to the same
    window that is then tested, so the residuals are shrunk by an unknown
    amount and the null must be generated by running the ESTIMATOR over
    simulated windows.

    Two consistency requirements, both of which the lookup depends on:

    * the null is indexed by the estimated (H_hat, SNR_eff), because those
      are the only coordinates available on real data;
    * it is generated in the same sigma_loc mode as the run -- handing the
      network a known sigma changes the residual distribution.

    D and dt are randomised over the training prior inside every cell: T and
    rho1 are invariant to both by scale invariance, so this marginalises them
    out rather than fixing them arbitrarily.  R is held at exactly R_ckpt --
    a mismatched exposure is what the test should DETECT, not absorb.
    """
    train = getattr(model, "cfg", None) or _net.Config(num_points=n,
                                                       exposure_R=R_ckpt)
    h_lo, h_hi = tuple(getattr(train, "h_range", (0.04, 0.96)))
    h_edges = np.linspace(h_lo, h_hi, cfg.gof_h_grid + 1)
    snr_edges = np.logspace(math.log10(cfg.gof_snr_range[0]),
                            math.log10(cfg.gof_snr_range[1]),
                            cfg.gof_snr_grid + 1)

    cache = cfg.gof_cache
    if cache and not cache.lower().endswith(".npz"):
        cache += ".npz"        # np.savez_compressed appends it anyway
    tag = hashlib.sha1(
        f"{os.path.abspath(cfg.weights)}|{os.path.getmtime(cfg.weights)}|"
        f"{n}|{R_ckpt}|{cfg.gof_sims}|{cfg.seed}|{int(known_sigma)}|"
        f"{h_edges.tobytes()}|{snr_edges.tobytes()}".encode()).hexdigest()[:12]
    if cache and os.path.exists(cache):
        with np.load(cache) as z:
            if str(z["tag"]) == tag:
                print(f"  goodness-of-fit null loaded from {cache}")
                return GofNull(z["h_edges"], z["snr_edges"], z["T"], z["Rho"],
                               z["offsets"], z["pooled_T"], z["pooled_Rho"],
                               cfg.gof_min_count)
        print(f"  {cache} was built for a different configuration; "
              f"recalibrating")

    n_cells = cfg.gof_h_grid * cfg.gof_snr_grid
    print(f"  calibrating the goodness-of-fit null: {n_cells} cells x "
          f"{cfg.gof_sims} windows ({'known' if known_sigma else 'unknown'} "
          f"sigma_loc)")
    allT, allR, allH, allS = [], [], [], []
    torch.manual_seed(cfg.seed)
    with torch.no_grad():
        for i in range(cfg.gof_h_grid):
            for j in range(cfg.gof_snr_grid):
                x, y, zc, t, _, _, sig_true, _ = _net.generate_fbm_dataset(
                    batch_size=cfg.gof_sims, cfg=train, device=device,
                    num_points=n,
                    h_range=(float(h_edges[i]), float(h_edges[i + 1])),
                    snr_range=(float(snr_edges[j]), float(snr_edges[j + 1])),
                    R_fixed=R_ckpt if R_ckpt > 0 else None)
                H, _, _, _, sg, s2, T, rho = _evaluate(
                    model, x, y, zc, t, sig_true if known_sigma else None,
                    R_ckpt, True)
                allH.append(H.cpu().numpy())
                allS.append(_snr_eff(H, sg, s2, R_ckpt))
                allT.append(T.cpu().numpy())
                allR.append(np.abs(rho.cpu().numpy()))

    H = np.concatenate(allH); S = np.concatenate(allS)
    T = np.concatenate(allT); R = np.concatenate(allR)
    finite = np.isfinite(H) & np.isfinite(S) & np.isfinite(T) & np.isfinite(R)
    H, S, T, R = H[finite], S[finite], T[finite], R[finite]

    null = GofNull(h_edges, snr_edges, None, None, None,
                   np.sort(T), np.sort(R), cfg.gof_min_count)
    b = null.bin_index(H, S)
    order = np.argsort(b, kind="stable")
    b, T, R = b[order], T[order], R[order]
    counts = np.bincount(b, minlength=n_cells)
    offsets = np.concatenate([[0], np.cumsum(counts)])
    for k in range(n_cells):                      # sort within each bin
        lo, hi = offsets[k], offsets[k + 1]
        T[lo:hi].sort(); R[lo:hi].sort()
    null.T, null.Rho, null.offsets = T, R, offsets

    thin = int((counts < cfg.gof_min_count).sum())
    if thin:
        print(f"  {thin}/{n_cells} bins hold fewer than {cfg.gof_min_count} "
              f"windows and fall back to the pooled null")
    if cache:
        np.savez_compressed(cache, tag=tag, h_edges=h_edges,
                            snr_edges=snr_edges, T=T, Rho=R, offsets=offsets,
                            pooled_T=null.pooled_T, pooled_Rho=null.pooled_Rho)
        print(f"  null cached to {cache}")
    return null


# ==========================================================================
# Per-segment scoring
# ==========================================================================

def score_windows(seg, n, stride, model, device, sigma_loc, batch_size,
                  R_ckpt, want_gof):
    """(starts, P) with P columns
    [H, sigma_H, log10D, sigma_log10D, sigma_loc, snr_eff, T, rho1]."""
    arr = {a: seg[a].to_numpy(np.float64) for a in ("x", "y", "z", "t")}
    sl_col = (seg["sigma_loc"].to_numpy(np.float64)
              if "sigma_loc" in seg.columns else None)

    starts = np.arange(0, len(seg) - n + 1, stride)
    if len(starts) == 0:
        return starts, None
    idx = starts[:, None] + np.arange(n)[None, :]

    chunks = []
    for i in range(0, len(starts), batch_size):
        j = idx[i:i + batch_size]
        xb, yb, zb = (_block(arr[a], j, device) for a in ("x", "y", "z"))
        tb = _block(arr["t"], j, device)
        if sigma_loc is not None:
            sl = torch.full((len(j),), float(sigma_loc), device=device)
        elif sl_col is not None:
            sl = torch.from_numpy(sl_col[j].mean(1).astype(np.float32)).to(device)
        else:
            sl = None
        with torch.no_grad():
            H, sH, l10D, s10D, sg, s2, T, rho = _evaluate(
                model, xb, yb, zb, tb, sl, R_ckpt, want_gof)
            snr = torch.from_numpy(_snr_eff(H, sg, s2, R_ckpt)).to(H.device)
        chunks.append(torch.stack([H, sH, l10D, s10D, sg, snr, T, rho],
                                  dim=1).cpu().numpy())
    return starts, np.concatenate(chunks)


# ==========================================================================
# Pipeline
# ==========================================================================

def process(cfg: ExpConfig = None):
    cfg = (CFG if cfg is None else cfg).validate()
    device = cfg.torch_device
    print(f"Network module: {_net.__name__}; scoring core: {_core.__name__}")
    print(f"Loading {cfg.weights} onto {device}")
    L = load_model(cfg.weights, device, cfg.num_points)
    n, R_ckpt = L.num_points, L.R_ckpt
    independent = cfg.stride >= n
    r_tol = L.r_jitter if cfg.r_tol is None else float(cfg.r_tol)
    print(f"Window {n} points, trained at R = {R_ckpt:g} "
          f"(+/-{100*L.r_jitter:g}%), accepting +/-{100*r_tol:g}%")
    if L.train_cfg:
        print(f"Training priors: H {L.train_cfg.get('h_range')}, "
              f"log10D {L.train_cfg.get('log10D_range')} dex "
              f"({cfg.d_unit} only if the units match), "
              f"dt {L.train_cfg.get('dt_range')}, "
              f"SNR {L.train_cfg.get('snr_range')}")

    df = ingest(cfg)
    print("Cleaning")
    df = clean(df, cfg)
    if cfg.drift_correct:
        df = correct_drift(df, cfg)
    aniso = isotropy_report(df, cfg)
    print(f"  {df['pid'].nunique()} tracks, {len(df)} localisations")

    if cfg.exposure_r is None and cfg.exposure_time is None and not any(
            c in df.columns for c in _core.R_COLUMNS):
        print(f"  WARNING: no exposure supplied. Assuming the data were "
              f"acquired at the checkpoint R = {R_ckpt:g}. Exposure blur and "
              f"low H leave the same signature in the increment correlation, "
              f"so an unknown R trades directly against H -- pass "
              f"--exposure-time from the camera settings.")

    known_sigma = cfg.sigma_loc is not None or "sigma_loc" in df.columns
    if cfg.sigma_loc is not None:
        print(f"  localisation precision fixed at {cfg.sigma_loc} "
              f"{cfg.length_unit}")
    elif known_sigma:
        print("  using the per-point sigma_loc column")
    else:
        print(f"  sigma_loc will be estimated (weakly identifiable from a "
              f"{n}-point window)")

    null = calibrate_gof(L.model, n, R_ckpt, cfg, device,
                         known_sigma) if cfg.gof else None

    rows, wrows, summary = [], [], []
    n_seg = n_win = n_short = n_rail = n_out = 0
    warned, sources = set(), set()

    for pid, traj in df.groupby("pid", sort=False):
        traj = traj.sort_values("t")
        segs, dt_track = split_segments(traj, cfg.dt, cfg.dt_tol)
        if not segs:
            continue
        R_data, src = track_exposure(traj, dt_track, cfg.exposure_r,
                                     cfg.exposure_time)
        check_exposure(R_data, R_ckpt, r_tol, pid, cfg.allow_r_mismatch, warned)
        R_used = R_ckpt if R_data is None else R_data
        sources.add(src or "assumed = checkpoint")

        tH, tD, tP, tn = [], [], [], 0
        for seg in segs:
            if len(seg) < n:
                n_short += 1
                continue
            starts, P = score_windows(seg, n, cfg.stride, L.model, device,
                                      cfg.sigma_loc, cfg.batch_size,
                                      R_ckpt, cfg.gof)
            if P is None:
                continue
            n_seg += 1
            n_win += len(starts)

            if L.h_bounds is not None:
                lo, hi = L.h_bounds
                n_rail += int(((P[:, 0] - lo < cfg.rail_tol)
                               | (hi - P[:, 0] < cfg.rail_tol)).sum())
            if L.log10D_range is not None:
                lo, hi = L.log10D_range
                n_out += int(((P[:, 2] < lo) | (P[:, 2] > hi)).sum())

            if null is not None:
                pT, pR = null.pvalues(P[:, 0], P[:, 5], P[:, 6], P[:, 7])
                pmin = np.clip(2.0 * np.minimum(pT, pR), 0.0, 1.0)  # Bonferroni
            else:
                pT = pR = pmin = np.full(len(starts), np.nan)

            m = len(seg)
            Hm, Hs, cnt = scatter_combine(m, starts, n, P[:, 0], P[:, 1],
                                          cfg.taper, independent)
            # combined in log10 (D is a scale parameter), converted at the end
            Dm, Ds, _ = scatter_combine(m, starts, n, P[:, 2], P[:, 3],
                                        cfg.taper, independent)
            SL = scatter_geomean(m, starts, n, P[:, 4], cfg.taper)
            # p-values are smoothed geometrically; this is a diagnostic
            # trace, not a calibrated per-timepoint test
            Pm = scatter_geomean(m, starts, n, np.clip(pmin, 1e-6, 1.0),
                                 cfg.taper)

            D_pred = np.power(10.0, Dm)
            out = pd.DataFrame({
                "pid": seg["pid"].to_numpy(),
                "t": seg["t"].to_numpy(),
                "H_predicted": Hm,
                "H_error": Hs,
                "D_predicted": D_pred,
                "D_error": D_pred * LN10 * Ds,      # delta method, dex -> linear
                "D_low": np.power(10.0, Dm - Ds),   # the honest 1-sd interval
                "D_high": np.power(10.0, Dm + Ds),
                "sigma_loc_predicted": SL,
                "n_windows": cnt,
                "exposure_R": R_used,
                "gof_p": Pm,
            })
            if cfg.msd_lag:
                out["MSD_at_lag"] = 2.0 * D_pred * cfg.msd_lag ** (2.0 * Hm)
            if cfg.log10_output:
                out["log10D_predicted"] = Dm
                out["log10D_error"] = Ds
            rows.append(out[out["n_windows"] >= cfg.min_windows])

            tH.append(P[:, 0]); tD.append(P[:, 2]); tP.append(pmin)
            tn += len(starts)

            if cfg.window_output is not None:
                ts = seg["t"].to_numpy()
                wD = np.power(10.0, P[:, 2])
                wrows.append(pd.DataFrame({
                    "pid": seg["pid"].iloc[0],
                    "t_start": ts[starts], "t_mid": ts[starts + n // 2],
                    "H_predicted": P[:, 0], "H_error": P[:, 1],
                    "D_predicted": wD, "D_error": wD * LN10 * P[:, 3],
                    "sigma_loc_predicted": P[:, 4],
                    "snr_effective": P[:, 5],
                    "gof_T": P[:, 6], "gof_rho1": P[:, 7],
                    "gof_p_scale": pT, "gof_p_corr": pR, "gof_p": pmin,
                    "exposure_R": R_used,
                }))

        if tn:
            tH = np.concatenate(tH); tD = np.concatenate(tD)
            rec = {"pid": pid, "n_localisations": len(traj),
                   "n_segments": len(segs), "n_windows": tn,
                   "H_median": float(np.median(tH)),
                   "H_iqr": float(np.subtract(*np.percentile(tH, [75, 25]))),
                   "D_median": float(10.0 ** np.median(tD)),
                   "log10D_iqr": float(np.subtract(*np.percentile(tD, [75, 25]))),
                   "exposure_R": R_used}
            if null is not None:
                tP = np.concatenate(tP)
                rec["gof_p_median"] = float(np.median(tP))
                rec["gof_frac_misfit"] = float(np.mean(tP < cfg.gof_alpha))
            summary.append(rec)

    if n_short:
        print(f"Skipped {n_short} segments shorter than {n} points.")
    if not rows:
        print("Warning: no usable windows.")
        return None

    if n_win:
        if n_rail / n_win > cfg.rail_warn_frac:
            print(f"WARNING: {100*n_rail/n_win:.1f}% of windows sit on the H "
                  f"bound {L.h_bounds}; the data extend past the training "
                  f"prior. Retrain with a wider h_range.")
        if n_out / n_win > cfg.rail_warn_frac:
            print(f"WARNING: {100*n_out/n_win:.1f}% of windows fall outside the "
                  f"training log10D prior {L.log10D_range} dex; those "
                  f"estimates are extrapolations. Check --pixel-size and "
                  f"--frame-interval before retraining -- a unit error moves "
                  f"log10 D by whole decades.")

    res = pd.concat(rows, ignore_index=True)
    print(f"{n_win} windows over {n_seg} segments -> {len(res)} timepoints "
          f"(window {n}, stride {cfg.stride}, taper {cfg.taper})")

    if null is not None and wrows:
        raw = pd.concat(wrows, ignore_index=True)["gof_p"].to_numpy()
        bad = float(np.mean(raw < cfg.gof_alpha))
        print(f"Goodness of fit: {100*bad:.1f}% of windows reject fBm at "
              f"alpha = {cfg.gof_alpha} (expected {100*cfg.gof_alpha:.0f}% if "
              f"the model holds)")
        if bad > 5 * cfg.gof_alpha:
            print("  A rejection rate this far above alpha means the tracks "
                  "are not fBm with a single (H, D) over the window: look for "
                  "confinement, directed motion, state switching, or a wrong "
                  "exposure R before interpreting H and D.")
    elif null is not None:
        bad = float(np.nanmean(res["gof_p"].to_numpy() < cfg.gof_alpha))
        print(f"Goodness of fit: {100*bad:.1f}% of timepoints below alpha = "
              f"{cfg.gof_alpha} on the smoothed p (use --window-output for "
              f"the per-window rate)")

    front = ["pid", "t", "H_predicted", "H_error", "D_predicted", "D_error",
             "D_low", "D_high", "log10D_predicted", "log10D_error",
             "MSD_at_lag", "sigma_loc_predicted", "gof_p", "n_windows",
             "exposure_R"]
    res = res[[c for c in front if c in res.columns]]

    with open(cfg.output, "w", newline="") as f:
        f.write("# MSD = 2 D t^(2H) per axis\n")
        f.write(f"# units: length {cfg.length_unit}, time {cfg.time_unit}, "
                f"D in {cfg.d_unit}, sigma_loc in {cfg.length_unit}\n")
        f.write(f"# pixel_size {cfg.pixel_size}, z_step {cfg.z_step}, "
                f"frame_interval {cfg.frame_interval}, drift_correct "
                f"{cfg.drift_correct}\n")
        f.write(f"# exposure: network trained at R = {R_ckpt:g} "
                f"(+/-{100*L.r_jitter:g}%); data R from "
                f"{'; '.join(sorted(sources))}\n")
        f.write(f"# sliding windows of {n} points, stride {cfg.stride}, "
                f"{'inverse-variance' if independent else 'common-mode'} "
                f"combination\n")
        f.write("# the network estimates log10(D); D_predicted = "
                "10^log10D_predicted\n")
        f.write("# H_error is a standard deviation; D_error = D_predicted * "
                "ln(10) * sigma_log10D (delta method, symmetric); D_low and "
                "D_high = 10^(log10D -/+ sigma_log10D) are the lognormal "
                "1-sd interval and should be preferred\n")
        if null is not None:
            f.write(f"# gof_p: simulation-calibrated p-value, min over the "
                    f"residual scale and lag-1 correlation tests "
                    f"(Bonferroni x2), null binned by the estimated (H, SNR) "
                    f"with {'known' if known_sigma else 'unknown'} sigma_loc; "
                    f"geometrically smoothed over overlapping windows -- a "
                    f"diagnostic trace, not a per-timepoint test\n")
        if aniso:
            f.write(f"# per-axis increment variance z/xy = "
                    f"{aniso['z_over_xy']:.2f} (one D and one sigma_loc are "
                    f"shared across x, y, z)\n")
        if cfg.msd_lag:
            f.write(f"# MSD_at_lag is the per-axis MSD at lag "
                    f"{cfg.msd_lag} {cfg.time_unit}, in "
                    f"{cfg.length_unit}^2 -- comparable across H, unlike D\n")
        res.to_csv(f, index=False)
    print(f"Per-timepoint file: {os.path.abspath(cfg.output)}")

    if cfg.track_summary and summary:
        pd.DataFrame(summary).to_csv(cfg.track_summary, index=False)
        print(f"Per-track summary: {os.path.abspath(cfg.track_summary)}")
    if cfg.window_output and wrows:
        pd.concat(wrows, ignore_index=True).to_csv(cfg.window_output,
                                                   index=False)
        print(f"Per-window file: {os.path.abspath(cfg.window_output)}")
    return res


# ==========================================================================
# Command line -- one flag per ExpConfig field, generated automatically
# ==========================================================================

def build_parser(cfg: ExpConfig) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=_DESCRIPTION,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    for f in fields(cfg):
        v = getattr(cfg, f.name)
        typ = f.metadata.get("type", type(v))
        flag = "--" + f.name.replace("_", "-")
        kw = {"default": None, "help": f.metadata.get("help", "")}
        if typ is bool:
            p.add_argument(flag, action="store_true", **kw)
            if v is True:                      # allow switching a default off
                p.add_argument("--no-" + f.name.replace("_", "-"),
                               dest=f.name + "_off", action="store_true",
                               help=f"disable {f.name}")
        elif isinstance(v, tuple):
            p.add_argument(flag, type=float, nargs=len(v), **kw)
        elif "choices" in f.metadata:
            p.add_argument(flag, type=typ, choices=f.metadata["choices"], **kw)
        else:
            p.add_argument(flag, type=typ, **kw)
    return p


def config_from_args(args, cfg: ExpConfig) -> ExpConfig:
    base = {f.name: getattr(cfg, f.name) for f in fields(cfg)}
    for f in fields(cfg):
        v = getattr(args, f.name, None)
        if v is not None and v is not False:
            base[f.name] = tuple(v) if isinstance(v, list) else v
        if getattr(args, f.name + "_off", False):
            base[f.name] = False
    return ExpConfig(**base)


if __name__ == "__main__":
    args = build_parser(CFG).parse_args()
    CFG = config_from_args(args, CFG)
    process(CFG)