"""
INFER_PINN_FBM_3D_LOG10_SLIDING.py
==================================

Sliding-window inference for the joint (H, D, sigma_loc) PINN estimator on
LONG trajectories.  Emits a per-timepoint H(t) and D(t) along each track,
one row per (pid, t), instead of one row per window.

All knobs live in the InferConfig dataclass below; every field is also a
command-line flag, generated automatically.

Dependencies
------------
This script depends on the NETWORK module only -- the file defining FBMPINN.
It does NOT import INFER_PINN_FBM_3D.py.  That import was removed
deliberately: a natural-log (version 2) copy of the non-sliding script often
sits in the same directory, and borrowing its loader here silently mixes
conventions.  The checkpoint loader is defined locally instead.

The network module is located by trying, in order: $PINN_MODULE, the exact
names PINN_FBM_3D / PINN_FBM_3D_LOG10 / PINN_FBM_3D_log10, and finally any
PINN_FBM_3D*.py in this directory (so a date- or version-stamped copy such
as PINN_FBM_3D_15SEP2026.py is found without setting PINN_MODULE).  Every
candidate is checked for FBMPINN before it is accepted.

Logarithm convention (MODEL_VERSION 3+)
---------------------------------------
The network returns log10(D) and its standard deviation in dex.  The delta
method therefore carries an extra factor of ln(10):

    D_error = D_predicted * ln(10) * sigma_log10D

Omitting it understates every error bar by 2.3026.  A version-2 checkpoint
(natural log) would load and run without complaint but yield
D_predicted = 10^(ln D), wrong by a D-dependent factor and silent -- so the
convention is checked at load time and refused rather than warned about.

Exposure blur (MODEL_VERSION 4)
-------------------------------
A version-4 checkpoint is specialised to ONE known exposure duty cycle
R = T_E/dt, stored as the model buffer `exposure_R` (authoritative) and in
config["exposure_R"], together with the training jitter config["r_jitter"].
The blur correction is inside the network, so inference needs no extra
input -- but it must check that the data were acquired at that R.  The data
R is taken, in order of priority, from

    --exposure-r R            one duty cycle for the whole file
    --exposure-time T_E       R = T_E / dt, dt per track (median diff(t))
    R_nominal / exposure_R    CSV column, constant within each track
    (none)                    assume the checkpoint R, and say so

and each track is refused if |R_data - R_ckpt| > r_tol * R_ckpt, with
r_tol = --r-tol or, by default, the checkpoint's training jitter (the range
over which the network was trained to be robust).  --allow-r-mismatch turns
the refusal into a warning; use exposure_mismatch_test() in the training
script to see what the resulting bias is.  Never pass the simulator's T_E or
R_true column as the data R: that is the jittered truth, not what an
experimentalist would report.

A version-3 checkpoint (no blur) loads as R = 0 and refuses data with R > 0
unless --allow-r-mismatch is given.

Training-domain diagnostics
---------------------------
Version-4 checkpoints carry the full training config, so the run reports the
fraction of windows whose H sits on the network's sigmoid bound and the
fraction whose log10 D falls outside the training prior.  Either exceeding
--rail-warn-frac means the data are outside the domain the network was
amortised over; retrain with wider h_range / log10D_range rather than
trusting the point estimates there.

What this adds over the fixed-window script
-------------------------------------------
* stride defaults to 1; every window of N points is scored
* each window's estimate is mapped back onto the timepoints it covers and
  the overlapping estimates are combined into one row per timepoint
* tracks are split into contiguous SEGMENTS at gaps in t, instead of the
  whole track being rejected for non-uniform sampling
* windows are streamed per segment, so track length is not bounded by memory

Combining overlapping windows
-----------------------------
At stride 1 two adjacent windows share N-2 increments, so their errors are
almost perfectly correlated.  The combination is therefore COMMON MODE:

    m = sum(u_w * x_w) / sum(u_w)
    s = sum(u_w * s_w) / sum(u_w)          <-- NOT sqrt(1/sum(1/s^2))

with u_w = taper_w / s_w^2.  An inverse-variance sd here would understate
the error by roughly sqrt(number of overlapping windows).  With --stride N
the windows are disjoint and inverse-variance is correct; the script
switches automatically.

D is combined in LOG10 space (it is a scale parameter) and converted at the
end; H is combined in linear space; sigma_loc is a taper-weighted geometric
mean.  The combination weights are scale-free, so moving from nats to dex
changes none of the combined point estimates.

Time resolution is set by the window length, not by the stride: every window
covering a change point straddles it.  --taper parabolic applies the
U-AnD-ME segment weight w(i) = (3/10)(2 - i~^2) so a window contributes most
near its own centre, but measured on a step change in D this bought
essentially nothing (MAE 0.277 vs 0.279 dex), which is why the default is
none.  Re-measure before turning it on.
"""

from __future__ import annotations

import argparse
import glob
import importlib
import math
import os
import sys
from dataclasses import dataclass, field, fields

import numpy as np
import pandas as pd
import torch

LN10 = math.log(10.0)        # dex -> nats, i.e. the delta-method factor
MIN_MODEL_VERSION = 3        # first version that reports log10(D)
BLUR_MODEL_VERSION = 4       # first version with a known exposure blur
R_COLUMNS = ("R_nominal", "exposure_R")   # accepted per-track R columns
TAPERS = ("none", "parabolic")

# argparse description.  Kept as a literal rather than sliced out of
# __doc__: docstrings are None under `python -OO`, and they are also lost if
# anything executable ever drifts above the triple-quoted block, which turns
# a working script into an AttributeError at start-up.
_DESCRIPTION = ("Sliding-window inference for the joint (H, D, sigma_loc) "
                "PINN estimator on long 3D trajectories. Emits one row per "
                "(pid, t).")


# ==========================================================================
# CONFIGURATION -- the single place to change anything
# ==========================================================================

def _opt(default, typ, help="", **meta):
    """A field whose default is None (or bool) but whose CLI type is fixed."""
    return field(default=default, metadata={"type": typ, "help": help, **meta})


@dataclass
class InferConfig:
    # ---- input / output --------------------------------------------------
    input: str = "FBM_3D_N20_SNR1_R0p05_dt0_02.csv"
    output: str = "predictions_FBM_FBM_3D_N20_SNR1_R0p05_dt0_02_sliding.csv"
    # default follows Config.ckpt_fmt in the training script
    weights: str = "fbm_pinn_N20_SNR1_R0.05_dt0_02.pt"
    window_output: str = _opt(None, str, "also write the raw per-window estimates")
    log10_output: bool = _opt(None, bool,
                              "also emit log10D_predicted and log10D_error [dex]")

    # ---- windowing -------------------------------------------------------
    num_points: int = _opt(None, int, "override the checkpoint window length")
    stride: int = 1
    taper: str = _opt("none", str, "per-window weight profile", choices=TAPERS)
    min_windows: int = 1

    # ---- sampling grid ---------------------------------------------------
    dt: float = _opt(None, float, "nominal sampling interval; median diff(t) if unset")
    dt_tol: float = 1e-3        # relative tolerance before a segment break

    # ---- exposure --------------------------------------------------------
    exposure_r: float = _opt(None, float, "data exposure duty cycle T_E/dt")
    exposure_time: float = _opt(None, float,
                                "data exposure time T_E, same units as t")
    r_tol: float = _opt(None, float,
                        "accepted relative R mismatch (default: checkpoint r_jitter)")
    allow_r_mismatch: bool = _opt(None, bool,
                                  "warn instead of refusing tracks outside --r-tol")

    # ---- localisation ----------------------------------------------------
    sigma_loc: float = _opt(None, float,
                            "known localisation precision (units of x,y,z)")

    # ---- training-domain diagnostics -------------------------------------
    rail_tol: float = 1e-3        # distance from the H bound counted as railed
    rail_warn_frac: float = 0.02  # warn above this fraction of windows

    # ---- compute ---------------------------------------------------------
    batch_size: int = 1024
    device: str = _opt(None, str, "cuda / cpu; autodetected if unset")

    def __post_init__(self):
        for name in ("log10_output", "allow_r_mismatch"):
            if getattr(self, name) is None:
                setattr(self, name, False)
        self.validate()

    def validate(self) -> "InferConfig":
        if self.stride < 1:
            raise ValueError(f"stride must be >= 1, got {self.stride}")
        if self.min_windows < 1:
            raise ValueError(f"min_windows must be >= 1, got {self.min_windows}")
        if self.dt_tol <= 0:
            raise ValueError(f"dt_tol must be positive, got {self.dt_tol}")
        if self.dt is not None and self.dt <= 0:
            raise ValueError(f"dt must be positive, got {self.dt}")
        if self.taper not in TAPERS:
            raise ValueError(f"taper must be one of {TAPERS}, got {self.taper!r}")
        if self.exposure_r is not None and self.exposure_time is not None:
            raise ValueError("give --exposure-r or --exposure-time, not both")
        if self.exposure_r is not None and not 0.0 <= self.exposure_r <= 1.0:
            raise ValueError(f"exposure_r must lie in [0, 1], got {self.exposure_r}")
        if self.num_points is not None and self.num_points < 3:
            raise ValueError(f"num_points must be >= 3, got {self.num_points}")
        if self.batch_size < 1:
            raise ValueError(f"batch_size must be >= 1, got {self.batch_size}")
        return self

    @property
    def torch_device(self):
        if self.device:
            return torch.device(self.device)
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")


CFG = InferConfig()


# ==========================================================================
# Network module resolution
# ==========================================================================

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

_MODULE_CANDIDATES = (
    os.environ.get("PINN_MODULE"),
    "PINN_FBM_3D",
    "PINN_FBM_3D_LOG10",
    "PINN_FBM_3D_log10",
)


def _try_module(name):
    """Import `name` and return it only if it defines FBMPINN."""
    try:
        mod = importlib.import_module(name)
    except ModuleNotFoundError as exc:
        # swallow only the failure to find THIS module; a missing torch or
        # numpy inside it must propagate
        if exc.name != name:
            raise
        return None
    return mod if hasattr(mod, "FBMPINN") else None


def _import_network():
    tried = []
    for name in _MODULE_CANDIDATES:
        if not name:
            continue
        tried.append(name)
        mod = _try_module(name)
        if mod is not None:
            return mod

    # fall back to any PINN_FBM_3D*.py sitting next to this file, so a
    # date- or version-stamped training script is found without PINN_MODULE
    seen = set(tried)
    for path in sorted(glob.glob(os.path.join(_HERE, "PINN_FBM_3D*.py")),
                       reverse=True):          # newest-looking name first
        name = os.path.splitext(os.path.basename(path))[0]
        if name in seen:
            continue
        seen.add(name)
        tried.append(name)
        mod = _try_module(name)
        if mod is not None:
            print(f"Using network module {name} (found by scanning {_HERE}).")
            return mod

    raise ModuleNotFoundError(
        "Could not find the PINN network module (the file defining FBMPINN).\n"
        f"  Tried    : {', '.join(tried) or '(nothing)'}\n"
        f"  Looked in: {_HERE}\n"
        "Either rename the training script to PINN_FBM_3D.py, or set the "
        "PINN_MODULE environment variable to its module name "
        "(filename without .py).")


_net = _import_network()
FBMPINN = _net.FBMPINN
_NET_VERSION = getattr(_net, "MODEL_VERSION", None)
_NET_CONFIG = getattr(_net, "Config", None)


# ==========================================================================
# Checkpoint loading and convention guard
# ==========================================================================

@dataclass
class Loaded:
    model: object
    num_points: int
    R_ckpt: float
    r_jitter: float
    train_cfg: dict            # the Config the network was trained with, as a dict
    h_bounds: tuple = None     # network sigmoid bounds on H, if known
    log10D_range: tuple = None  # training prior on log10 D, if known


def check_log_convention(cfg, weights_path):
    """Refuse a checkpoint that does not report D in log10.

    A version-2 (natural log) checkpoint loads and runs without error but
    returns ln D where this script expects log10 D, so every D comes out as
    D^(1/ln10) -- a silent, D-dependent error.  Better to stop here.
    """
    base, ver = cfg.get("log"), cfg.get("version")
    if base != "log10":
        raise ValueError(
            f"{weights_path}: checkpoint reports D in '{base}' "
            f"(version {ver}); this script requires log10 "
            f"(MODEL_VERSION >= {MIN_MODEL_VERSION}). Retrain with the log10 "
            f"training script, or use the version-2 inference scripts.")
    if ver is not None and ver < MIN_MODEL_VERSION:
        raise ValueError(f"{weights_path}: MODEL_VERSION {ver} < "
                         f"{MIN_MODEL_VERSION}")
    if _NET_VERSION is not None and ver is not None and ver != _NET_VERSION:
        print(f"Warning: checkpoint MODEL_VERSION {ver} != network module "
              f"MODEL_VERSION {_NET_VERSION} ({_net.__name__}).")
    return cfg


def _construct(n, R_ckpt, train_cfg):
    """Build the network, preferring the Config API of the current module."""
    if _NET_CONFIG is not None:
        known = {f.name for f in fields(_NET_CONFIG)}
        base = {k: v for k, v in train_cfg.items() if k in known}
        base["num_points"] = n
        base["exposure_R"] = R_ckpt
        try:
            cfg = _NET_CONFIG(**base)
        except (TypeError, ValueError) as exc:
            print(f"Warning: checkpoint config rejected by {_net.__name__}."
                  f"Config ({exc}); falling back to module defaults.")
            cfg = _NET_CONFIG(num_points=n, exposure_R=R_ckpt)
        return FBMPINN(cfg), cfg
    # legacy modules: keyword constructor, with or without blur
    try:
        return FBMPINN(num_points=n, exposure_R=R_ckpt), None
    except TypeError:
        if R_ckpt > 0:
            raise ValueError(
                f"The network module {_net.__name__} (MODEL_VERSION "
                f"{_NET_VERSION}) predates exposure blur; it cannot host a "
                f"version-{BLUR_MODEL_VERSION} checkpoint trained at "
                f"R = {R_ckpt:g}. Point PINN_MODULE at the current training "
                f"script.")
        return FBMPINN(num_points=n), None


def load_model(weights_path, device, num_points=None) -> Loaded:
    """Rebuild the network at the checkpoint's window length and exposure.

    Defined here rather than imported, so this script cannot pick up a
    natural-log loader left in the same directory.
    """
    if not os.path.exists(weights_path):
        raise FileNotFoundError(
            f"Checkpoint not found: {weights_path}\n"
            f"  Looked in: {os.path.abspath(os.path.dirname(weights_path) or '.')}\n"
            f"The training script names checkpoints by its ckpt_fmt, e.g. "
            f"fbm_pinn_N20_R0.05.pt; pass --weights explicitly.")
    ck = torch.load(weights_path, map_location=device, weights_only=False)
    if isinstance(ck, dict) and "model_state" in ck:
        state, train_cfg = ck["model_state"], dict(ck.get("config", {}))
    else:
        state, train_cfg = ck, {}
    check_log_convention(train_cfg, weights_path)

    n = num_points or train_cfg.get("num_points")
    if n is None:
        # in_dim = 3(N-1) + 2, so N = (in_dim - 2)/3 + 1
        in_dim = state["shared.0.weight"].shape[1]
        n = (in_dim - 2) // 3 + 1
        print(f"Checkpoint carries no num_points; inferred N={n} from the "
              f"input layer.")

    net_has_blur = hasattr(_net, "blur_variance_factor")
    if "exposure_R" in state:
        if not net_has_blur:
            raise ValueError(
                f"{weights_path}: checkpoint was trained with exposure blur "
                f"(R = {float(state['exposure_R']):g}) but the network module "
                f"{_net.__name__} predates it (MODEL_VERSION {_NET_VERSION}). "
                f"Point PINN_MODULE at the version-{BLUR_MODEL_VERSION} "
                f"training script.")
        R_ckpt = float(state["exposure_R"])
        cfg_R = train_cfg.get("exposure_R")
        if cfg_R is not None and abs(float(cfg_R) - R_ckpt) > 1e-9:
            print(f"Warning: config exposure_R {cfg_R} != model buffer "
                  f"{R_ckpt:g}; using the buffer.")
    else:
        R_ckpt = 0.0
        print(f"Checkpoint predates exposure blur (version "
              f"{train_cfg.get('version')}): instantaneous sampling, R = 0.")
        if net_has_blur:
            state = dict(state)
            state["exposure_R"] = torch.tensor(0.0, dtype=torch.float64)

    model, net_cfg = _construct(n, R_ckpt, train_cfg)
    model = model.to(device)
    model.load_state_dict(state)
    model.eval()

    h_bounds = getattr(net_cfg, "h_net_range", None)
    d_range = getattr(net_cfg, "log10D_range", None) or train_cfg.get("log10D_range")
    return Loaded(model=model, num_points=n, R_ckpt=R_ckpt,
                  r_jitter=float(train_cfg.get("r_jitter", 0.0)),
                  train_cfg=train_cfg, h_bounds=h_bounds,
                  log10D_range=tuple(d_range) if d_range else None)


# ==========================================================================
# Exposure check
# ==========================================================================

def track_exposure(traj, dt, exposure_r=None, exposure_time=None):
    """Data duty cycle for one track and where it came from, or (None, None)."""
    if exposure_r is not None:
        return float(exposure_r), "--exposure-r"
    if exposure_time is not None:
        return float(exposure_time) / dt, "--exposure-time / dt"
    for col in R_COLUMNS:
        if col in traj.columns:
            v = traj[col].dropna().to_numpy()
            if len(v) == 0:
                continue
            if np.ptp(v) > 1e-9 * max(1.0, float(np.abs(v).max())):
                raise ValueError(f"pid {traj['pid'].iloc[0]}: column {col} "
                                 f"is not constant within the track: {v[:5]}")
            return float(v[0]), f"column {col}"
    return None, None


def check_exposure(R_data, R_ckpt, r_tol, pid, allow_mismatch, warned):
    """Refuse (or warn about) a track acquired at a different R."""
    if R_data is None:
        return
    if not 0.0 <= R_data <= 1.0:
        raise ValueError(f"pid {pid}: exposure duty cycle R = {R_data:g} "
                         f"outside [0, 1] -- is T_E in the same units as t?")
    bad = (abs(R_data - R_ckpt) > r_tol * R_ckpt + 1e-12 if R_ckpt > 0
           else R_data > 1e-12)
    if not bad:
        return
    msg = (f"pid {pid}: data R = {R_data:g} but the network was trained at "
           f"R = {R_ckpt:g} (tolerance +/-{100 * r_tol:g}%)")
    if not allow_mismatch:
        raise ValueError(msg + ". Retrain at this R, or pass "
                               "--allow-r-mismatch to proceed biased.")
    key = round(R_data, 6)
    if key not in warned:
        warned.add(key)
        print("Warning: " + msg + "; estimates will be biased.")


# ==========================================================================
# Segmentation and window weights
# ==========================================================================

def split_segments(traj, dt_nominal=None, dt_tol=1e-3):
    """Split one track into contiguous, uniformly sampled segments."""
    t = traj["t"].to_numpy(np.float64)
    if len(t) < 2:
        return [], None
    d = np.diff(t)
    dt = float(dt_nominal) if dt_nominal is not None else float(np.median(d))
    if dt <= 0:
        raise ValueError(f"pid {traj['pid'].iloc[0]}: time column is not "
                         f"strictly increasing (dt = {dt:g})")
    breaks = np.nonzero(np.abs(d - dt) > max(dt_tol * dt, 1e-12))[0]
    segs, start = [], 0
    for b in breaks:
        if b + 1 > start:
            segs.append(traj.iloc[start:b + 1])
        start = b + 1
    segs.append(traj.iloc[start:])
    return [s for s in segs if len(s) >= 2], dt


def taper_weights(n, kind):
    if kind == "none":
        return np.ones(n)
    it = np.linspace(-1.0, 1.0, n)
    return 0.3 * (2.0 - it ** 2)          # U-AnD-ME parabolic segment weight


# ==========================================================================
# Scatter / combine
# ==========================================================================

def scatter_combine(m, starts, n, vals, sigs, taper, independent):
    """Map per-window (value, sd) onto timepoints and combine.

    Unit-agnostic: for D, vals are log10 D and sigs are in dex, and the
    result is returned in the same units.
    """
    w = taper_weights(n, taper)[None, :]
    idx = (starts[:, None] + np.arange(n)[None, :]).ravel()
    var = np.maximum(np.asarray(sigs, float) ** 2, 1e-30)[:, None]
    u = (w / var).ravel()

    acc_u = np.zeros(m); acc_v = np.zeros(m); acc_s = np.zeros(m)
    acc_iv = np.zeros(m); cnt = np.zeros(m, int)
    np.add.at(acc_u, idx, u)
    np.add.at(acc_v, idx, u * np.repeat(np.asarray(vals, float), n))
    np.add.at(acc_s, idx, u * np.repeat(np.asarray(sigs, float), n))
    np.add.at(acc_iv, idx, np.broadcast_to(1.0 / var, (len(starts), n)).ravel())
    np.add.at(cnt, idx, 1)

    good = acc_u > 0
    mean = np.full(m, np.nan); sd = np.full(m, np.nan)
    mean[good] = acc_v[good] / acc_u[good]
    if independent:
        # disjoint windows: plain inverse-variance, taper only reweights
        # the point estimate
        sd[good] = np.sqrt(1.0 / acc_iv[good])
    else:
        sd[good] = acc_s[good] / acc_u[good]
    return mean, sd, cnt


def scatter_geomean(m, starts, n, vals, taper):
    """Taper-weighted geometric mean onto timepoints (for sigma_loc).

    Done in log10 for consistency with the rest of the pipeline; the
    geometric mean itself is of course base-independent.
    """
    w = taper_weights(n, taper)[None, :]
    idx = (starts[:, None] + np.arange(n)[None, :]).ravel()
    u = np.broadcast_to(w, (len(starts), n)).ravel()
    acc_u = np.zeros(m); acc_v = np.zeros(m)
    np.add.at(acc_u, idx, u)
    np.add.at(acc_v, idx, u * np.repeat(np.log10(np.maximum(vals, 1e-30)), n))
    out = np.full(m, np.nan)
    g = acc_u > 0
    out[g] = np.power(10.0, acc_v[g] / acc_u[g])
    return out


# ==========================================================================
# Per-segment scoring
# ==========================================================================

def _block(a, j, device):
    """Gather windows in float64, re-zero each to its own first sample, cast.

    Re-zeroing is exact for the network -- it only ever uses differences --
    and it is what makes float32 safe.  Casting the raw coordinates instead
    costs ~1e-3 absolute on values of order 1e4, which is 10% of a typical
    increment, and the same truncation on t corrupts the mean dt that sets
    the log10 D reconstruction.
    """
    w = a[j]
    return torch.from_numpy(np.ascontiguousarray(
        (w - w[:, :1]).astype(np.float32))).to(device)


def score_windows(seg, n, stride, model, device, sigma_loc, batch_size):
    """Returns (starts, P) with P columns
    [H, sigma_H, log10D, sigma_log10D, sigma_loc]."""
    x = seg["x"].to_numpy(np.float64)
    y = seg["y"].to_numpy(np.float64)
    z = seg["z"].to_numpy(np.float64)
    t = seg["t"].to_numpy(np.float64)
    sl_col = (seg["sigma_loc"].to_numpy(np.float64)
              if "sigma_loc" in seg.columns else None)

    starts = np.arange(0, len(seg) - n + 1, stride)
    if len(starts) == 0:
        return starts, None
    idx = starts[:, None] + np.arange(n)[None, :]

    chunks = []
    for i in range(0, len(starts), batch_size):
        j = idx[i:i + batch_size]
        xb, yb, zb = _block(x, j, device), _block(y, j, device), _block(z, j, device)
        tb = _block(t, j, device)
        if sigma_loc is not None:
            sl = torch.full((len(j),), float(sigma_loc), device=device)
        elif sl_col is not None:
            sl = torch.from_numpy(
                sl_col[j].mean(1).astype(np.float32)).to(device)
        else:
            sl = None
        with torch.no_grad():
            H, sH, l10D, s10D, sg = model(xb, yb, zb, tb, sl)
        chunks.append(torch.stack([H, sH, l10D, s10D, sg], dim=1).cpu().numpy())
    return starts, np.concatenate(chunks)


# ==========================================================================
# Pipeline
# ==========================================================================

def process(cfg: InferConfig = None):
    cfg = (CFG if cfg is None else cfg).validate()
    device = cfg.torch_device
    print(f"Network module: {_net.__name__} (MODEL_VERSION {_NET_VERSION})")
    print(f"Loading network model onto {device}...")
    L = load_model(cfg.weights, device, cfg.num_points)
    n, R_ckpt = L.num_points, L.R_ckpt
    independent = cfg.stride >= n
    r_tol = L.r_jitter if cfg.r_tol is None else float(cfg.r_tol)
    print(f"Exposure: network trained at R = T_E/dt = {R_ckpt:g} "
          f"(training jitter +/-{100 * L.r_jitter:g}%, "
          f"accepting data within +/-{100 * r_tol:g}%)")
    if L.train_cfg:
        print(f"Training priors: H {L.train_cfg.get('h_range')}, "
              f"log10D {L.train_cfg.get('log10D_range')} dex, "
              f"dt {L.train_cfg.get('dt_range')}, "
              f"SNR {L.train_cfg.get('snr_range')}")

    print(f"Reading target trajectory file: {cfg.input}")
    df = pd.read_csv(cfg.input)
    df.columns = [c.strip() for c in df.columns]
    if "t" not in df.columns and "time" in df.columns:
        df = df.rename(columns={"time": "t"})
    missing = {"pid", "x", "y", "z", "t"} - set(df.columns)
    if missing:
        raise ValueError(f"Input CSV is missing required columns: {sorted(missing)}")
    if "D" not in df.columns and "log10D" in df.columns:
        df["D"] = np.power(10.0, df["log10D"].to_numpy(np.float64))
    has_truth = {"H", "D"}.issubset(df.columns)
    if not has_truth:
        print("No H/D columns found - writing predictions only.")

    r_col = next((c for c in R_COLUMNS if c in df.columns), None)
    if cfg.exposure_r is None and cfg.exposure_time is None and r_col is None:
        print(f"No exposure given (--exposure-r, --exposure-time or a "
              f"{'/'.join(R_COLUMNS)} column): ASSUMING the data were "
              f"acquired at the checkpoint R = {R_ckpt:g}.")

    if cfg.sigma_loc is not None:
        print(f"Using supplied localisation precision sigma_loc={cfg.sigma_loc}")
    elif "sigma_loc" in df.columns:
        print("Using the sigma_loc column")
    else:
        print(f"sigma_loc not supplied - it will be estimated (weakly "
              f"identifiable from a {n}-point window)")

    rows, wrows = [], []
    n_seg = n_win = n_short = n_rail = n_out = 0
    warned, sources = set(), set()

    for pid, traj in df.groupby("pid", sort=False):
        traj = traj.sort_values("t")
        segs, dt_track = split_segments(traj, cfg.dt, cfg.dt_tol)
        if not segs:
            continue
        R_data, src = track_exposure(traj, dt_track, cfg.exposure_r,
                                     cfg.exposure_time)
        check_exposure(R_data, R_ckpt, r_tol, pid, cfg.allow_r_mismatch, warned)
        R_used = R_ckpt if R_data is None else R_data
        sources.add(src or "assumed = checkpoint")

        for seg in segs:
            if len(seg) < n:
                n_short += 1
                continue
            n_seg += 1
            starts, P = score_windows(seg, n, cfg.stride, L.model, device,
                                      cfg.sigma_loc, cfg.batch_size)
            if P is None:
                continue
            n_win += len(starts)

            # training-domain diagnostics, on the raw per-window estimates
            if L.h_bounds is not None:
                lo, hi = L.h_bounds
                n_rail += int(((P[:, 0] - lo < cfg.rail_tol)
                               | (hi - P[:, 0] < cfg.rail_tol)).sum())
            if L.log10D_range is not None:
                lo, hi = L.log10D_range
                n_out += int(((P[:, 2] < lo) | (P[:, 2] > hi)).sum())

            m = len(seg)
            Hm, Hs, cnt = scatter_combine(m, starts, n, P[:, 0], P[:, 1],
                                          cfg.taper, independent)
            # Dm is log10 D, Ds is its sd in dex
            Dm, Ds, _ = scatter_combine(m, starts, n, P[:, 2], P[:, 3],
                                        cfg.taper, independent)
            SL = scatter_geomean(m, starts, n, P[:, 4], cfg.taper)

            D_pred = np.power(10.0, Dm)
            out = pd.DataFrame({
                "pid": seg["pid"].to_numpy(),
                "t": seg["t"].to_numpy(),
                "H_predicted": Hm,
                "H_error": Hs,
                "D_predicted": D_pred,
                "D_error": D_pred * LN10 * Ds,     # delta method, dex -> linear
                "sigma_loc_predicted": SL,
                "n_windows": cnt,
                "exposure_R": R_used,
            })
            if cfg.log10_output:
                out["log10D_predicted"] = Dm
                out["log10D_error"] = Ds
            if has_truth:
                out.insert(2, "H", seg["H"].to_numpy())
                out.insert(3, "D", seg["D"].to_numpy())
            rows.append(out[out["n_windows"] >= cfg.min_windows])

            if cfg.window_output is not None:
                ts = seg["t"].to_numpy()
                wD = np.power(10.0, P[:, 2])
                w = pd.DataFrame({
                    "pid": seg["pid"].iloc[0],
                    "t_start": ts[starts],
                    "t_mid": ts[starts + n // 2],
                    "H_predicted": P[:, 0], "H_error": P[:, 1],
                    "D_predicted": wD,
                    "D_error": wD * LN10 * P[:, 3],
                    "sigma_loc_predicted": P[:, 4],
                    "exposure_R": R_used,
                })
                if cfg.log10_output:
                    w["log10D_predicted"] = P[:, 2]
                    w["log10D_error"] = P[:, 3]
                wrows.append(w)

    if n_short:
        print(f"Skipped {n_short} segments shorter than {n} points.")
    if not rows:
        print("Warning: no usable windows.")
        return

    if n_win:
        if n_rail / n_win > cfg.rail_warn_frac:
            print(f"Warning: {100 * n_rail / n_win:.1f}% of windows sit on the "
                  f"network's H bound {L.h_bounds}; the data extend past the "
                  f"training prior. Retrain with a wider h_range.")
        if n_out / n_win > cfg.rail_warn_frac:
            print(f"Warning: {100 * n_out / n_win:.1f}% of windows fall outside "
                  f"the training log10D prior {L.log10D_range} dex; those "
                  f"estimates are extrapolations.")

    res = pd.concat(rows, ignore_index=True)
    print(f"{n_win} windows over {n_seg} segments -> {len(res)} timepoints "
          f"(window {n}, stride {cfg.stride}, taper {cfg.taper})")

    front = ["pid", "t", "H", "H_predicted", "H_error", "D", "D_predicted",
             "D_error", "log10D_predicted", "log10D_error",
             "sigma_loc_predicted", "n_windows", "exposure_R"]
    res = res[[c for c in front if c in res.columns]]

    with open(cfg.output, "w", newline="") as f:
        f.write("# MSD = 2 D t^(2H) per axis\n")
        f.write(f"# box exposure blur: network trained at R = T_E/dt = "
                f"{R_ckpt:g} (+/-{100 * L.r_jitter:g}%); exposure_R column = "
                f"data R ({'; '.join(sorted(sources))})\n")
        f.write(f"# training priors: H {L.train_cfg.get('h_range')}, "
                f"log10D {L.train_cfg.get('log10D_range')} dex\n")
        f.write(f"# per-timepoint estimates from sliding windows of {n} "
                f"points, stride {cfg.stride}, "
                f"{'inverse-variance' if independent else 'common-mode'} "
                f"combination\n")
        f.write("# the network estimates log10(D); D_predicted = "
                "10^log10D_predicted\n")
        f.write("# H_error is a standard deviation; D_error = D_predicted * "
                "ln(10) * sigma_log10D (delta method)\n")
        if cfg.log10_output:
            f.write("# log10D_error is a standard deviation in dex\n")
        res.to_csv(f, index=False)

    if cfg.window_output is not None and wrows:
        pd.concat(wrows, ignore_index=True).to_csv(cfg.window_output, index=False)
        print(f"Per-window file: {os.path.abspath(cfg.window_output)}")

    if has_truth:
        e = np.log10(res["D_predicted"] / res["D"])
        print(f"H MAE {np.abs(res['H_predicted'] - res['H']).mean():.4f} | "
              f"log10(D) MAE {e.abs().mean():.4f} dex | "
              f"bias {e.mean():+.4f} dex")
    print(f"File written to: {os.path.abspath(cfg.output)}")
    return res



# ==========================================================================
# Command line -- one flag per InferConfig field, generated automatically
# ==========================================================================

def build_parser(cfg: InferConfig) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=_DESCRIPTION,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    for f in fields(cfg):
        v = getattr(cfg, f.name)
        typ = f.metadata.get("type", type(v))
        flag = "--" + f.name.replace("_", "-")
        kw = {"default": None, "help": f.metadata.get("help", "")}
        if typ is bool:
            p.add_argument(flag, action="store_true", **kw)
        elif "choices" in f.metadata:
            p.add_argument(flag, type=typ, choices=f.metadata["choices"], **kw)
        else:
            p.add_argument(flag, type=typ, **kw)
    return p


def config_from_args(args, cfg: InferConfig) -> InferConfig:
    base = {f.name: getattr(cfg, f.name) for f in fields(cfg)}
    for f in fields(cfg):
        v = getattr(args, f.name, None)
        if v is not None:
            base[f.name] = v
    return InferConfig(**base)


if __name__ == "__main__":
    args = build_parser(CFG).parse_args()
    CFG = config_from_args(args, CFG)
    process(CFG)